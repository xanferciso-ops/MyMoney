export interface Category {
  id: number;
  name: string;
  icon: string;
  iconType?: 'material' | 'emoji';
  type: 'pengeluaran' | 'pendapatan';
  color: string;
}

export interface Wallet {
  id: number;
  name: string;
  icon: string;
  color: string;
}

export interface Transaction {
  id: number;
  type: 'pendapatan' | 'pengeluaran' | 'pro';
  amount: number;
  note: string;
  categoryId: number;
  walletId: number;
  date: string;
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
}

export interface ProBudget {
  catId: number | string;
  limit: number;
}

export interface ProGoal {
  name: string;
  target: number;
  saved: number;
  date?: string;
}

export interface ProDebt {
  person: string;
  type: 'utang' | 'piutang';
  amount: number;
  due?: string;
  note?: string;
}

export interface ProBill {
  name: string;
  amount: number;
  due?: string;
  cycle: 'Mingguan' | 'Bulanan' | 'Tahunan';
}

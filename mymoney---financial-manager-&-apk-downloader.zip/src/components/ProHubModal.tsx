import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  Calculator,
  PiggyBank,
  Target,
  HandCoins,
  Receipt,
  Search,
  Database,
  Trash2,
  CheckCircle,
  PlusCircle,
  MinusCircle,
  Download,
  Upload,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import {
  Category,
  Transaction,
  Wallet,
  Currency,
  ProBudget,
  ProGoal,
  ProDebt,
  ProBill
} from '../types';
import { parseNominal, formatCurrency, calculateGoalProgress, calculateNextBillDueDate } from '../utils/moneyLogic';

interface ProHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  isBalanceVisible: boolean;
  transactions: Transaction[];
  categories: Category[];
  wallets: Wallet[];
  budgets: ProBudget[];
  goals: ProGoal[];
  debts: ProDebt[];
  bills: ProBill[];
  onSaveBudgets: (b: ProBudget[]) => void;
  onSaveGoals: (g: ProGoal[]) => void;
  onSaveDebts: (d: ProDebt[]) => void;
  onSaveBills: (b: ProBill[]) => void;
  onAddTransaction: (tx: Omit<Transaction, 'id'>) => void;
  onDeleteTransaction: (id: number) => void;
  onRestoreData: (data: any) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const ProHubModal: React.FC<ProHubModalProps> = ({
  isOpen,
  onClose,
  currency,
  isBalanceVisible,
  transactions,
  categories,
  wallets,
  budgets,
  goals,
  debts,
  bills,
  onSaveBudgets,
  onSaveGoals,
  onSaveDebts,
  onSaveBills,
  onAddTransaction,
  onDeleteTransaction,
  onRestoreData,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<
    'ringkasan' | 'ratarata' | 'anggaran' | 'tujuan' | 'utang' | 'tagihan' | 'cari' | 'cadangan'
  >('ringkasan');

  // Form states
  const [budgetCatId, setBudgetCatId] = useState<number>(categories[0]?.id || 1);
  const [budgetLimitStr, setBudgetLimitStr] = useState<string>('');

  const [goalName, setGoalName] = useState<string>('');
  const [goalTargetStr, setGoalTargetStr] = useState<string>('');
  const [goalSavedStr, setGoalSavedStr] = useState<string>('');
  const [goalDate, setGoalDate] = useState<string>('');
  const [goalFundInputs, setGoalFundInputs] = useState<Record<number, string>>({});

  const [debtPerson, setDebtPerson] = useState<string>('');
  const [debtType, setDebtType] = useState<'utang' | 'piutang'>('utang');
  const [debtAmountStr, setDebtAmountStr] = useState<string>('');
  const [debtDue, setDebtDue] = useState<string>('');
  const [debtNote, setDebtNote] = useState<string>('');
  const [debtPayInputs, setDebtPayInputs] = useState<Record<number, string>>({});

  const [billName, setBillName] = useState<string>('');
  const [billAmountStr, setBillAmountStr] = useState<string>('');
  const [billDue, setBillDue] = useState<string>('');
  const [billCycle, setBillCycle] = useState<'Mingguan' | 'Bulanan' | 'Tahunan'>('Bulanan');
  const [billPayInputs, setBillPayInputs] = useState<Record<number, string>>({});

  // Search states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchFrom, setSearchFrom] = useState<string>('');
  const [searchTo, setSearchTo] = useState<string>('');
  const [searchType, setSearchType] = useState<string>('');

  if (!isOpen) return null;

  const currentMonthKey = new Date().toISOString().slice(0, 7);
  const monthExpenseTxs = transactions.filter(
    t => String(t.date || '').slice(0, 7) === currentMonthKey && t.type === 'pengeluaran'
  );
  const totalMonthExpense = monthExpenseTxs.reduce((s, t) => s + t.amount, 0);

  const displayMoney = (num: number) => {
    if (!isBalanceVisible) return `${currency.symbol} •••••••`;
    return formatCurrency(num, currency.symbol);
  };

  // Helper format input
  const handleNumericInput = (e: React.ChangeEvent<HTMLInputElement>, setter: (v: string) => void) => {
    const val = e.target.value.replace(/\D/g, '');
    setter(val ? parseInt(val, 10).toLocaleString('id-ID') : '');
  };

  // Budgets
  const handleAddBudget = () => {
    const limit = parseNominal(budgetLimitStr);
    if (!budgetCatId || limit <= 0) {
      onShowToast('Masukkan batas anggaran yang valid!', 'error');
      return;
    }
    const existing = [...budgets];
    const idx = existing.findIndex(b => String(b.catId) === String(budgetCatId));
    if (idx >= 0) {
      existing[idx].limit = limit;
    } else {
      existing.push({ catId: budgetCatId, limit });
    }
    onSaveBudgets(existing);
    setBudgetLimitStr('');
    onShowToast('Batas anggaran berhasil disimpan!');
  };

  const handleDeleteBudget = (index: number) => {
    const updated = [...budgets];
    updated.splice(index, 1);
    onSaveBudgets(updated);
    onShowToast('Anggaran dihapus');
  };

  // Goals
  const handleAddGoal = () => {
    const target = parseNominal(goalTargetStr);
    const saved = parseNominal(goalSavedStr);
    if (!goalName.trim() || target <= 0) {
      onShowToast('Isi nama dan target tabungan dengan benar!', 'error');
      return;
    }
    const updated = [...goals, { name: goalName.trim(), target, saved, date: goalDate }];
    onSaveGoals(updated);
    setGoalName('');
    setGoalTargetStr('');
    setGoalSavedStr('');
    setGoalDate('');
    onShowToast('Target tabungan berhasil dibuat!');
  };

  const handleFundGoal = (index: number, action: 'setor' | 'tarik') => {
    const g = goals[index];
    if (!g) return;
    const amount = parseNominal(goalFundInputs[index]);
    if (amount <= 0) {
      onShowToast('Masukkan nominal valid!', 'error');
      return;
    }

    const defaultWallet = wallets[0]?.id || 101;
    const expCat = categories.find(c => c.type === 'pengeluaran') || categories[0];
    const incCat = categories.find(c => c.type === 'pendapatan') || categories[0];

    const updated = [...goals];
    if (action === 'setor') {
      updated[index].saved += amount;
      onAddTransaction({
        type: 'pengeluaran',
        amount,
        note: `Setor Tabungan: ${g.name}`,
        categoryId: expCat.id,
        walletId: defaultWallet,
        date: new Date().toISOString()
      });
      onShowToast(`Berhasil setor ${displayMoney(amount)} ke ${g.name}`);
    } else {
      if (amount > g.saved) {
        onShowToast('Nominal penarikan melebihi saldo tabungan!', 'error');
        return;
      }
      updated[index].saved -= amount;
      onAddTransaction({
        type: 'pendapatan',
        amount,
        note: `Tarik Tabungan: ${g.name}`,
        categoryId: incCat.id,
        walletId: defaultWallet,
        date: new Date().toISOString()
      });
      onShowToast(`Berhasil menarik ${displayMoney(amount)} dari ${g.name}`);
    }
    onSaveGoals(updated);
    setGoalFundInputs(prev => ({ ...prev, [index]: '' }));
  };

  const handleDeleteGoal = (index: number) => {
    const updated = [...goals];
    updated.splice(index, 1);
    onSaveGoals(updated);
    onShowToast('Target tabungan dihapus');
  };

  // Debts
  const handleAddDebt = () => {
    const amount = parseNominal(debtAmountStr);
    if (!debtPerson.trim() || amount <= 0) {
      onShowToast('Isi nama dan nominal utang/piutang!', 'error');
      return;
    }
    const updated = [
      ...debts,
      {
        person: debtPerson.trim(),
        type: debtType,
        amount,
        due: debtDue,
        note: debtNote.trim()
      }
    ];
    onSaveDebts(updated);
    setDebtPerson('');
    setDebtAmountStr('');
    setDebtDue('');
    setDebtNote('');
    onShowToast('Catatan utang/piutang disimpan!');
  };

  const handlePayDebt = (index: number, isFull: boolean) => {
    const d = debts[index];
    if (!d) return;
    const amount = isFull ? d.amount : parseNominal(debtPayInputs[index]);
    if (amount <= 0) {
      onShowToast('Masukkan nominal pembayaran valid!', 'error');
      return;
    }
    const actualPay = Math.min(amount, d.amount);
    const updated = [...debts];
    updated[index].amount -= actualPay;

    const isUtang = d.type === 'utang';
    const defaultWallet = wallets[0]?.id || 101;
    const cat = categories.find(c => c.type === (isUtang ? 'pengeluaran' : 'pendapatan')) || categories[0];

    onAddTransaction({
      type: isUtang ? 'pengeluaran' : 'pendapatan',
      amount: actualPay,
      note: isUtang ? `Bayar Utang: ${d.person}` : `Terima Piutang: ${d.person}`,
      categoryId: cat.id,
      walletId: defaultWallet,
      date: new Date().toISOString()
    });

    if (updated[index].amount <= 0) {
      updated.splice(index, 1);
      onShowToast(`Utang/Piutang dengan ${d.person} telah LUNAS! 🎉`);
    } else {
      onShowToast(`Pembayaran ${displayMoney(actualPay)} berhasil dicatat`);
    }
    onSaveDebts(updated);
    setDebtPayInputs(prev => ({ ...prev, [index]: '' }));
  };

  const handleDeleteDebt = (index: number) => {
    const updated = [...debts];
    updated.splice(index, 1);
    onSaveDebts(updated);
    onShowToast('Catatan dihapus');
  };

  // Bills
  const handleAddBill = () => {
    const amount = parseNominal(billAmountStr);
    if (!billName.trim() || amount < 0) {
      onShowToast('Isi nama tagihan dengan benar!', 'error');
      return;
    }
    const updated = [...bills, { name: billName.trim(), amount, due: billDue, cycle: billCycle }];
    onSaveBills(updated);
    setBillName('');
    setBillAmountStr('');
    setBillDue('');
    onShowToast('Pengingat tagihan disimpan!');
  };

  const handlePayBill = (index: number) => {
    const b = bills[index];
    if (!b) return;
    const customAmount = parseNominal(billPayInputs[index]) || b.amount;
    if (customAmount <= 0) {
      onShowToast('Nominal tagihan harus lebih dari 0', 'error');
      return;
    }

    const defaultWallet = wallets[0]?.id || 101;
    const catExp = categories.find(c => c.type === 'pengeluaran') || categories[0];

    onAddTransaction({
      type: 'pengeluaran',
      amount: customAmount,
      note: `Bayar Tagihan: ${b.name}`,
      categoryId: catExp.id,
      walletId: defaultWallet,
      date: new Date().toISOString()
    });

    const updated = [...bills];
    if (b.due) {
      updated[index].due = calculateNextBillDueDate(b.due, b.cycle);
    }
    onSaveBills(updated);
    onShowToast(`Tagihan ${b.name} (${displayMoney(customAmount)}) berhasil dibayar!`);
  };

  const handleDeleteBill = (index: number) => {
    const updated = [...bills];
    updated.splice(index, 1);
    onSaveBills(updated);
    onShowToast('Tagihan dihapus');
  };

  // Export & Restore JSON
  const handleExportBackup = () => {
    const data = {
      app: 'MyMoney',
      backupVersion: 2,
      createdAt: new Date().toISOString(),
      categories,
      wallets,
      transactions,
      pro: { budgets, goals, debts, bills }
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MyMoney_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    onShowToast('File backup JSON berhasil diunduh!');
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (parsed.app !== 'MyMoney' || !Array.isArray(parsed.transactions)) {
          throw new Error('Format salah');
        }
        onRestoreData(parsed);
        onShowToast('Data backup berhasil dipulihkan!');
      } catch {
        onShowToast('File backup rusak atau tidak sesuai!', 'error');
      }
    };
    reader.readAsText(file);
  };

  // Filtered search
  const filteredTxs = transactions.filter(t => {
    const cat = categories.find(c => c.id === t.categoryId);
    const fullText = [t.note, cat?.name, t.amount, t.date, t.type].join(' ').toLowerCase();
    const matchQ = fullText.includes(searchQuery.toLowerCase());
    const matchFrom = !searchFrom || t.date >= searchFrom;
    const matchTo = !searchTo || t.date <= searchTo;
    const matchType = !searchType || t.type === searchType;
    return matchQ && matchFrom && matchTo && matchType;
  });

  return (
    <div className="fixed inset-0 z-[200] bg-slate-950 flex flex-col text-slate-100 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="p-4 bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div>
          <span className="text-[10px] font-black tracking-widest text-blue-400 uppercase">
            MYMONEY • PRO HUB
          </span>
          <h2 className="text-base font-extrabold text-white">Pusat Keuangan Pro</h2>
        </div>
        <button
          onClick={onClose}
          aria-label="Tutup Pusat Pro"
          className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1 transition"
        >
          <X className="w-4 h-4" />
          <span>Tutup</span>
        </button>
      </div>

      {/* Navigation Grid (8 buttons) */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 p-2 bg-slate-900/90 border-b border-slate-800 text-[10px] font-extrabold shrink-0">
        {[
          { id: 'ringkasan', label: 'Ringkasan', icon: TrendingUp },
          { id: 'ratarata', label: 'Rata-Rata', icon: Calculator },
          { id: 'anggaran', label: 'Anggaran', icon: PiggyBank },
          { id: 'tujuan', label: 'Tujuan', icon: Target },
          { id: 'utang', label: 'Utang', icon: HandCoins },
          { id: 'tagihan', label: 'Tagihan', icon: Receipt },
          { id: 'cari', label: 'Cari Data', icon: Search },
          { id: 'cadangan', label: 'Backup', icon: Database }
        ].map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 transition ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-black'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* RINGKASAN */}
        {activeTab === 'ringkasan' && (
          <div className="space-y-4 max-w-2xl mx-auto">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <p className="text-[11px] text-slate-400">Pengeluaran Bulan Ini</p>
                <p className="text-lg font-black text-white my-1">{displayMoney(totalMonthExpense)}</p>
                <p className="text-[10px] text-slate-500">{monthExpenseTxs.length} transaksi</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <p className="text-[11px] text-slate-400">Batas Anggaran Total</p>
                <p className="text-lg font-black text-blue-400 my-1">
                  {displayMoney(budgets.reduce((s, b) => s + b.limit, 0))}
                </p>
                <p className="text-[10px] text-slate-500">{budgets.length} kategori diatur</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <p className="text-[11px] text-slate-400">Target Tabungan</p>
                <p className="text-lg font-black text-emerald-400 my-1">
                  {displayMoney(goals.reduce((s, g) => s + g.saved, 0))}
                </p>
                <p className="text-[10px] text-slate-500">Dari {goals.length} target impian</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <p className="text-[11px] text-slate-400">Utang/Piutang Aktif</p>
                <p className="text-lg font-black text-amber-400 my-1">
                  {displayMoney(debts.reduce((s, d) => s + d.amount, 0))}
                </p>
                <p className="text-[10px] text-slate-500">{debts.length} catatan aktif</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <h3 className="font-bold text-sm text-white mb-2">Pintasan Analisis Keuangan</h3>
              <p className="text-slate-400 text-xs leading-relaxed mb-4">
                Pusat Pro menyediakan fitur lengkap untuk memantau rata-rata harian, membatasi pengeluaran bulanan, mengumpulkan tabungan, hingga melacak jatuh tempo tagihan.
              </p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setActiveTab('ratarata')}
                  className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition"
                >
                  📊 Analisis Rata-Rata
                </button>
                <button
                  onClick={() => setActiveTab('anggaran')}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
                >
                  🎯 Atur Anggaran Belanja
                </button>
              </div>
            </div>
          </div>
        )}

        {/* RATA-RATA */}
        {activeTab === 'ratarata' && (
          <div className="space-y-4 max-w-2xl mx-auto">
            {(() => {
              const now = new Date();
              const daysPassed = Math.max(1, now.getDate());
              const totalDaysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
              const avgDaily = Math.round(totalMonthExpense / daysPassed);
              const avgPerTx = monthExpenseTxs.length ? Math.round(totalMonthExpense / monthExpenseTxs.length) : 0;
              const projectedMonthEnd = Math.round(avgDaily * totalDaysInMonth);

              let biggestTx: Transaction | null = null;
              monthExpenseTxs.forEach(t => {
                if (!biggestTx || t.amount > biggestTx.amount) biggestTx = t;
              });

              return (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                      <p className="text-[11px] text-slate-400">Rata-Rata Harian</p>
                      <p className="text-lg font-black text-amber-400 my-1">{displayMoney(avgDaily)}</p>
                      <p className="text-[10px] text-slate-500">Dihitung selama {daysPassed} hari bulan ini</p>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                      <p className="text-[11px] text-slate-400">Rata-Rata Per Transaksi</p>
                      <p className="text-lg font-black text-blue-400 my-1">{displayMoney(avgPerTx)}</p>
                      <p className="text-[10px] text-slate-500">Dari {monthExpenseTxs.length} kali pengeluaran</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                    <h3 className="font-bold text-sm text-white mb-1">Estimasi Pengeluaran Akhir Bulan</h3>
                    <p className="text-xs text-slate-400 mb-2">
                      Jika pola konsumsi Anda berlanjut hingga akhir bulan ({totalDaysInMonth} hari):
                    </p>
                    <p className="text-2xl font-black text-red-400">{displayMoney(projectedMonthEnd)}</p>
                  </div>

                  {biggestTx && (
                    <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                      <h3 className="font-bold text-sm text-white mb-2">Pengeluaran Terbesar Bulan Ini</h3>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-bold text-xs text-white">{(biggestTx as Transaction).note}</p>
                          <p className="text-[10px] text-slate-500">{(biggestTx as Transaction).date.slice(0, 10)}</p>
                        </div>
                        <span className="font-black text-sm text-red-400">
                          {displayMoney((biggestTx as Transaction).amount)}
                        </span>
                      </div>
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        )}

        {/* ANGGARAN */}
        {activeTab === 'anggaran' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {/* Form */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Set Patokan Anggaran</h3>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Kategori Pengeluaran</label>
                <select
                  value={budgetCatId}
                  onChange={e => setBudgetCatId(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                >
                  {categories.filter(c => c.type === 'pengeluaran').map(c => (
                    <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Batas Maksimal Per Bulan</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={budgetLimitStr}
                  onChange={e => handleNumericInput(e, setBudgetLimitStr)}
                  placeholder="Contoh: 1.500.000"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <button
                onClick={handleAddBudget}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition"
              >
                Simpan Anggaran
              </button>
            </div>

            {/* List */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Batas Anggaran Aktif</h3>
              {budgets.length === 0 ? (
                <p className="text-xs text-slate-500">Belum ada batas anggaran yang diatur.</p>
              ) : (
                budgets.map((b, i) => {
                  const cat = categories.find(c => String(c.id) === String(b.catId));
                  const spent = monthExpenseTxs
                    .filter(t => String(t.categoryId) === String(b.catId))
                    .reduce((s, t) => s + t.amount, 0);
                  const pct = Math.min(100, Math.round((spent / Math.max(1, b.limit)) * 100));
                  const isOver = spent >= b.limit;

                  return (
                    <div key={i} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-white flex items-center gap-1.5">
                          <span>{cat?.icon || '•'}</span>
                          <span>{cat?.name || 'Kategori Dihapus'}</span>
                        </span>
                        <div className="flex items-center gap-2">
                          <span className={`font-black ${isOver ? 'text-red-400' : 'text-blue-400'}`}>{pct}%</span>
                          <button
                            onClick={() => handleDeleteBudget(i)}
                            className="text-slate-400 hover:text-red-400 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            isOver ? 'bg-red-500' : 'bg-gradient-to-r from-blue-500 to-indigo-500'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>Terpakai: {displayMoney(spent)}</span>
                        <span>Limit: {displayMoney(b.limit)}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* TUJUAN */}
        {activeTab === 'tujuan' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {/* Form */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Buat Target Tabungan Impian</h3>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Nama Target</label>
                <input
                  type="text"
                  value={goalName}
                  onChange={e => setGoalName(e.target.value)}
                  placeholder="Misal: Beli Motor Baru"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Nominal</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={goalTargetStr}
                  onChange={e => handleNumericInput(e, setGoalTargetStr)}
                  placeholder="Contoh: 15.000.000"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Tabungan Awal (Opsional)</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={goalSavedStr}
                  onChange={e => handleNumericInput(e, setGoalSavedStr)}
                  placeholder="0"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Target Tanggal</label>
                <input
                  type="date"
                  value={goalDate}
                  onChange={e => setGoalDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <button
                onClick={handleAddGoal}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition"
              >
                Simpan Target
              </button>
            </div>

            {/* List */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Daftar Tabungan Impian</h3>
              {goals.length === 0 ? (
                <p className="text-xs text-slate-500">Belum ada target tabungan.</p>
              ) : (
                goals.map((g, i) => {
                  const pct = calculateGoalProgress(g.target, g.saved);
                  const isDone = pct >= 100;

                  return (
                    <div key={i} className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2.5">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-xs text-white">{g.name}</p>
                          {isDone ? (
                            <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              🎉 Target Tercapai!
                            </span>
                          ) : (
                            g.date && <p className="text-[10px] text-slate-400">🎯 Tempo: {g.date}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`font-black text-xs ${isDone ? 'text-emerald-400' : 'text-blue-400'}`}>
                            {pct}%
                          </span>
                          <button onClick={() => handleDeleteGoal(i)} className="text-slate-400 hover:text-red-400">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            isDone ? 'bg-emerald-500' : 'bg-gradient-to-r from-blue-500 to-indigo-500'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>

                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>Terkumpul: <b className="text-white">{displayMoney(g.saved)}</b></span>
                        <span>Target: {displayMoney(g.target)}</span>
                      </div>

                      {/* Setor/Tarik Controls */}
                      <div className="pt-1.5 border-t border-slate-700/60 space-y-1.5">
                        <input
                          type="text"
                          inputMode="numeric"
                          value={goalFundInputs[i] || ''}
                          onChange={e => {
                            const val = e.target.value.replace(/\D/g, '');
                            setGoalFundInputs(prev => ({
                              ...prev,
                              [i]: val ? parseInt(val, 10).toLocaleString('id-ID') : ''
                            }));
                          }}
                          placeholder="Nominal (cth: 50.000)"
                          className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => handleFundGoal(i, 'setor')}
                            className="py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                            <span>Setor</span>
                          </button>
                          <button
                            onClick={() => handleFundGoal(i, 'tarik')}
                            className="py-1.5 px-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs flex items-center justify-center gap-1"
                          >
                            <MinusCircle className="w-3.5 h-3.5" />
                            <span>Tarik</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* UTANG */}
        {activeTab === 'utang' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {/* Form */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Catat Utang / Piutang</h3>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Nama Orang / Pihak</label>
                <input
                  type="text"
                  value={debtPerson}
                  onChange={e => setDebtPerson(e.target.value)}
                  placeholder="Contoh: Budi, Warung, Toko"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Jenis</label>
                <select
                  value={debtType}
                  onChange={e => setDebtType(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                >
                  <option value="utang">Saya Berutang (Bayar = Pengeluaran)</option>
                  <option value="piutang">Piutang (Diterima = Pendapatan)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Nominal</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={debtAmountStr}
                  onChange={e => handleNumericInput(e, setDebtAmountStr)}
                  placeholder="Contoh: 100.000"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Jatuh Tempo</label>
                <input
                  type="date"
                  value={debtDue}
                  onChange={e => setDebtDue(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Catatan</label>
                <input
                  type="text"
                  value={debtNote}
                  onChange={e => setDebtNote(e.target.value)}
                  placeholder="Opsional..."
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <button
                onClick={handleAddDebt}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition"
              >
                Simpan Catatan
              </button>
            </div>

            {/* List */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Daftar Utang & Piutang</h3>
              {debts.length === 0 ? (
                <p className="text-xs text-slate-500">Belum ada catatan utang/piutang.</p>
              ) : (
                debts.map((d, i) => {
                  const isUtang = d.type === 'utang';
                  return (
                    <div key={i} className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-xs text-white">{d.person}</p>
                          <span
                            className={`inline-block mt-0.5 px-2 py-0.5 rounded text-[9px] font-bold ${
                              isUtang
                                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            }`}
                          >
                            {isUtang ? '🔴 Saya Berutang' : '🟢 Piutang Saya'}
                          </span>
                        </div>
                        <button onClick={() => handleDeleteDebt(i)} className="text-slate-400 hover:text-red-400">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] text-slate-300">
                        <p>Sisa: <b className="text-white">{displayMoney(d.amount)}</b></p>
                        {d.due && <p className="text-slate-400 text-[10px]">🗓️ Tempo: {d.due}</p>}
                        {d.note && <p className="text-slate-400 text-[10px]">📝 Note: {d.note}</p>}
                      </div>

                      {/* Pay block */}
                      <div className="pt-2 border-t border-slate-700/60 space-y-1.5">
                        <input
                          type="text"
                          inputMode="numeric"
                          value={debtPayInputs[i] || ''}
                          onChange={e => {
                            const val = e.target.value.replace(/\D/g, '');
                            setDebtPayInputs(prev => ({
                              ...prev,
                              [i]: val ? parseInt(val, 10).toLocaleString('id-ID') : ''
                            }));
                          }}
                          placeholder={`Nominal cicil (cth: ${d.amount.toLocaleString('id-ID')})`}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => handlePayDebt(i, false)}
                            className="py-1.5 px-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
                          >
                            {isUtang ? 'Bayar Cicilan' : 'Terima Cicilan'}
                          </button>
                          <button
                            onClick={() => handlePayDebt(i, true)}
                            className="py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                          >
                            Pelunasan Total
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* TAGIHAN */}
        {activeTab === 'tagihan' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {/* Form */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Tambah Pengingat Tagihan</h3>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Nama Tagihan</label>
                <input
                  type="text"
                  value={billName}
                  onChange={e => setBillName(e.target.value)}
                  placeholder="Misal: Wi-Fi Indihome, BPJS, Kos"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Perkiraan Nominal</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={billAmountStr}
                  onChange={e => handleNumericInput(e, setBillAmountStr)}
                  placeholder="Contoh: 350.000"
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Jatuh Tempo Berikutnya</label>
                <input
                  type="date"
                  value={billDue}
                  onChange={e => setBillDue(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Siklus</label>
                <select
                  value={billCycle}
                  onChange={e => setBillCycle(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                >
                  <option value="Bulanan">Bulanan</option>
                  <option value="Mingguan">Mingguan</option>
                  <option value="Tahunan">Tahunan</option>
                </select>
              </div>
              <button
                onClick={handleAddBill}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition"
              >
                Simpan Pengingat
              </button>
            </div>

            {/* List */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Daftar Tagihan Rutin</h3>
              {bills.length === 0 ? (
                <p className="text-xs text-slate-500">Belum ada pengingat tagihan.</p>
              ) : (
                bills.map((b, i) => {
                  const todayStr = new Date().toISOString().slice(0, 10);
                  const isNearDue = b.due && b.due <= todayStr;

                  return (
                    <div key={i} className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-xs text-white">{b.name}</p>
                          <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[9px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                            🔄 {b.cycle}
                          </span>
                        </div>
                        <button onClick={() => handleDeleteBill(i)} className="text-slate-400 hover:text-red-400">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px]">
                        <p className="text-slate-300">Nominal: <b className="text-white">{displayMoney(b.amount)}</b></p>
                        <p className={`${isNearDue ? 'text-red-400 font-bold' : 'text-slate-400'} text-[10px]`}>
                          🗓️ Tempo: {b.due || 'Tanpa Tanggal'}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-700/60 space-y-1.5">
                        <input
                          type="text"
                          inputMode="numeric"
                          value={billPayInputs[i] ?? b.amount.toLocaleString('id-ID')}
                          onChange={e => {
                            const val = e.target.value.replace(/\D/g, '');
                            setBillPayInputs(prev => ({
                              ...prev,
                              [i]: val ? parseInt(val, 10).toLocaleString('id-ID') : ''
                            }));
                          }}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                        />
                        <button
                          onClick={() => handlePayBill(i)}
                          className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                          <span>Bayar & Perbarui Tempo</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* CARI */}
        {activeTab === 'cari' && (
          <div className="space-y-4 max-w-2xl mx-auto">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Cari Transaksi Lengkap</h3>
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Ketik kata kunci catatan, nominal, atau kategori..."
                className="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
              />
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="date"
                  value={searchFrom}
                  onChange={e => setSearchFrom(e.target.value)}
                  className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
                <input
                  type="date"
                  value={searchTo}
                  onChange={e => setSearchTo(e.target.value)}
                  className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
                <select
                  value={searchType}
                  onChange={e => setSearchType(e.target.value)}
                  className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                >
                  <option value="">Semua Jenis</option>
                  <option value="pengeluaran">Pengeluaran</option>
                  <option value="pendapatan">Pendapatan</option>
                </select>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <p className="text-[11px] text-slate-400 font-bold uppercase">
                Hasil Pencarian ({filteredTxs.length})
              </p>
              {filteredTxs.length === 0 ? (
                <p className="text-xs text-slate-500 py-3 text-center">Tidak ada transaksi yang cocok.</p>
              ) : (
                filteredTxs.slice(0, 50).map(t => {
                  const cat = categories.find(c => c.id === t.categoryId);
                  const isInc = t.type === 'pendapatan';
                  return (
                    <div
                      key={t.id}
                      className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between"
                    >
                      <div className="truncate pr-2">
                        <p className="font-bold text-xs text-white truncate">{t.note}</p>
                        <p className="text-[10px] text-slate-400">{t.date.slice(0, 10)} • {cat?.name}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className={`font-black text-xs ${isInc ? 'text-emerald-400' : 'text-red-400'}`}>
                          {isInc ? '+' : '-'}{displayMoney(t.amount)}
                        </span>
                        <button
                          onClick={() => onDeleteTransaction(t.id)}
                          className="text-slate-400 hover:text-red-400 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* CADANGAN */}
        {activeTab === 'cadangan' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Ekspor Backup JSON</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Simpan seluruh riwayat keuangan, kategori, dompet, batas anggaran, target tabungan, dan utang piutang ke satu file JSON di memori HP Anda.
              </p>
              <button
                onClick={handleExportBackup}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition"
              >
                <Download className="w-4 h-4" />
                <span>Unduh File Backup JSON</span>
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Pulihkan Backup JSON</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Kembalikan data keuangan Anda dari berkas backup JSON yang pernah disimpan sebelumnya.
              </p>
              <input
                type="file"
                accept="application/json,.json"
                onChange={handleFileRestore}
                className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

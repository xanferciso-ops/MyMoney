import React, { useState } from 'react';
import {
  X,
  ArrowLeft,
  Wallet as WalletIcon,
  Tags,
  Coins,
  Globe,
  Palette,
  Download,
  Shield,
  Info,
  Trash2,
  Smartphone,
  Plus,
  Check
} from 'lucide-react';
import { Category, Wallet, Currency } from '../types';
import { CURRENCY_LIST, LANGUAGES_LIST } from '../utils/constants';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onSelectCurrency: (c: Currency) => void;
  language: string;
  onSelectLanguage: (l: string) => void;
  displayMode: 'dark' | 'light' | 'system';
  onSelectDisplayMode: (m: 'dark' | 'light' | 'system') => void;
  categories: Category[];
  onAddCategory: (cat: Category) => void;
  onDeleteCategory: (id: number) => void;
  wallets: Wallet[];
  onAddWallet: (w: Wallet) => void;
  onDeleteWallet: (id: number) => void;
  onExportCSV: () => void;
  onResetData: () => void;
  onOpenApkModal: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currency,
  onSelectCurrency,
  language,
  onSelectLanguage,
  displayMode,
  onSelectDisplayMode,
  categories,
  onAddCategory,
  onDeleteCategory,
  wallets,
  onAddWallet,
  onDeleteWallet,
  onExportCSV,
  onResetData,
  onOpenApkModal,
  onShowToast
}) => {
  const [subView, setSubView] = useState<
    'main' | 'wallets' | 'categories' | 'currency' | 'language' | 'theme' | 'privacy'
  >('main');

  // Add Category form state
  const [newCatName, setNewCatName] = useState('');
  const [newCatEmoji, setNewCatEmoji] = useState('📦');
  const [newCatType, setNewCatType] = useState<'pengeluaran' | 'pendapatan'>('pengeluaran');
  const [newCatColor, setNewCatColor] = useState('#3B82F6');

  // Add Wallet form state
  const [newWalName, setNewWalName] = useState('');
  const [newWalEmoji, setNewWalEmoji] = useState('💳');
  const [newWalColor, setNewWalColor] = useState('#3B82F6');

  if (!isOpen) return null;

  const handleCreateCategory = () => {
    if (!newCatName.trim()) {
      onShowToast('Isi nama kategori!', 'error');
      return;
    }
    onAddCategory({
      id: Date.now(),
      name: newCatName.trim(),
      icon: newCatEmoji || '📦',
      type: newCatType,
      color: newCatColor
    });
    setNewCatName('');
    onShowToast('Kategori baru ditambahkan!');
  };

  const handleCreateWallet = () => {
    if (!newWalName.trim()) {
      onShowToast('Isi nama dompet!', 'error');
      return;
    }
    onAddWallet({
      id: Date.now(),
      name: newWalName.trim(),
      icon: newWalEmoji || '💳',
      color: newWalColor
    });
    setNewWalName('');
    onShowToast('Dompet baru ditambahkan!');
  };

  return (
    <div className="fixed inset-0 z-[220] bg-slate-950 flex flex-col text-slate-100 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          {subView !== 'main' && (
            <button
              onClick={() => setSubView('main')}
              className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-base font-extrabold text-white">
            {subView === 'main' && 'Setelan'}
            {subView === 'wallets' && 'Kelola Dompet'}
            {subView === 'categories' && 'Kelola Kategori'}
            {subView === 'currency' && 'Pilih Mata Uang'}
            {subView === 'language' && 'Pilih Bahasa'}
            {subView === 'theme' && 'Mode Tampilan'}
            {subView === 'privacy' && 'Kebijakan Privasi'}
          </h2>
        </div>
        <button
          onClick={onClose}
          aria-label="Tutup setelan"
          className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 max-w-xl mx-auto w-full space-y-6">
        {subView === 'main' && (
          <div className="space-y-5 text-xs">
            {/* APK Highlight Banner */}
            <div
              onClick={() => {
                onClose();
                onOpenApkModal();
              }}
              className="p-4 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 cursor-pointer shadow-lg shadow-blue-500/20 text-white flex items-center justify-between transition"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-black text-sm">Download APK & Bagikan</p>
                  <p className="text-[11px] text-blue-100">Pasang di Handphone / Kirim ke Teman</p>
                </div>
              </div>
              <Download className="w-5 h-5 text-white/90" />
            </div>

            {/* PENGELOLAAN */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                PENGELOLAAN
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-800/80">
                <div
                  onClick={() => setSubView('wallets')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <WalletIcon className="w-4 h-4 text-blue-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Dompet</p>
                      <p className="text-[10px] text-slate-400">Atur akun & sumber dana ({wallets.length} dompet)</p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>

                <div
                  onClick={() => setSubView('categories')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Tags className="w-4 h-4 text-amber-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Kategori</p>
                      <p className="text-[10px] text-slate-400">Kelola kategori pengeluaran & pemasukan</p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>

                <div
                  onClick={() => setSubView('currency')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Coins className="w-4 h-4 text-emerald-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Mata Uang</p>
                      <p className="text-[10px] text-blue-400 font-semibold">{currency.name}</p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>

                <div
                  onClick={() => setSubView('language')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Globe className="w-4 h-4 text-purple-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Bahasa</p>
                      <p className="text-[10px] text-blue-400 font-semibold">
                        {LANGUAGES_LIST.find(l => l.code === language)?.name || 'Bahasa Indonesia 🇮🇩'}
                      </p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>
              </div>
            </div>

            {/* KONFIGURASI */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                KONFIGURASI
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-800/80">
                <div
                  onClick={() => setSubView('theme')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Palette className="w-4 h-4 text-pink-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Tema & Mode Tampilan</p>
                      <p className="text-[10px] text-slate-400 capitalize">Mode: {displayMode}</p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>
              </div>
            </div>

            {/* CADANGAN DATA */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                CADANGAN DATA
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-800/80">
                <div
                  onClick={onExportCSV}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Download className="w-4 h-4 text-blue-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Ekspor Data (Excel/CSV)</p>
                      <p className="text-[10px] text-slate-400">Unduh laporan keuangan ke file lokal HP</p>
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-slate-500" />
                </div>
              </div>
            </div>

            {/* LAIN-LAIN */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">
                LAIN-LAIN
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-800/80">
                <div
                  onClick={() => setSubView('privacy')}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-850 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Kebijakan Privasi</p>
                      <p className="text-[10px] text-slate-400">Aplikasi 100% Offline & Aman</p>
                    </div>
                  </div>
                  <span className="text-slate-500">›</span>
                </div>

                <div className="p-3.5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Info className="w-4 h-4 text-slate-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Versi Aplikasi</p>
                      <p className="text-[10px] text-slate-400">2.6.0 Pro Edition</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    Terbaru
                  </span>
                </div>

                <div
                  onClick={onResetData}
                  className="p-3.5 flex items-center justify-between hover:bg-red-500/10 cursor-pointer transition"
                >
                  <div className="flex items-center gap-3">
                    <Trash2 className="w-4 h-4 text-red-400" />
                    <div>
                      <p className="font-bold text-red-400 text-xs">Reset Semua Data</p>
                      <p className="text-[10px] text-red-300/70">Hapus seluruh riwayat transaksi & mulai baru</p>
                    </div>
                  </div>
                  <Trash2 className="w-4 h-4 text-red-400" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBVIEW: WALLETS */}
        {subView === 'wallets' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Tambah Dompet Baru</h3>
              <div className="grid grid-cols-4 gap-2">
                <input
                  type="text"
                  value={newWalName}
                  onChange={e => setNewWalName(e.target.value)}
                  placeholder="Nama Dompet..."
                  className="col-span-2 p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
                <input
                  type="text"
                  value={newWalEmoji}
                  onChange={e => setNewWalEmoji(e.target.value)}
                  placeholder="Emoji"
                  className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white text-center outline-none"
                />
                <input
                  type="color"
                  value={newWalColor}
                  onChange={e => setNewWalColor(e.target.value)}
                  className="w-full h-full min-h-[38px] rounded-xl bg-transparent cursor-pointer"
                />
              </div>
              <button
                onClick={handleCreateWallet}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Plus className="w-4 h-4" />
                <span>Simpan Dompet</span>
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="font-bold text-xs text-slate-400 uppercase tracking-widest px-1">
                Daftar Dompet ({wallets.length})
              </h3>
              {wallets.map(w => (
                <div
                  key={w.id}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
                      style={{ backgroundColor: `${w.color}25`, color: w.color }}
                    >
                      {w.icon}
                    </span>
                    <span className="font-bold text-xs text-white">{w.name}</span>
                  </div>
                  {wallets.length > 1 && (
                    <button
                      onClick={() => onDeleteWallet(w.id)}
                      className="p-2 text-slate-400 hover:text-red-400 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBVIEW: CATEGORIES */}
        {subView === 'categories' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-white">Tambah Kategori Baru</h3>
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={newCatName}
                  onChange={e => setNewCatName(e.target.value)}
                  placeholder="Nama Kategori..."
                  className="col-span-2 p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                />
                <input
                  type="text"
                  value={newCatEmoji}
                  onChange={e => setNewCatEmoji(e.target.value)}
                  placeholder="Emoji"
                  className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white text-center outline-none"
                />
                <select
                  value={newCatType}
                  onChange={e => setNewCatType(e.target.value as any)}
                  className="col-span-2 p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white outline-none"
                >
                  <option value="pengeluaran">Pengeluaran</option>
                  <option value="pendapatan">Pendapatan</option>
                </select>
                <input
                  type="color"
                  value={newCatColor}
                  onChange={e => setNewCatColor(e.target.value)}
                  className="w-full h-full min-h-[38px] rounded-xl bg-transparent cursor-pointer"
                />
              </div>
              <button
                onClick={handleCreateCategory}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Plus className="w-4 h-4" />
                <span>Simpan Kategori</span>
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="font-bold text-xs text-slate-400 uppercase tracking-widest px-1">
                Daftar Kategori ({categories.length})
              </h3>
              {categories.map(c => (
                <div
                  key={c.id}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
                      style={{ backgroundColor: `${c.color}25`, color: c.color }}
                    >
                      {c.icon}
                    </span>
                    <div>
                      <p className="font-bold text-xs text-white">{c.name}</p>
                      <p
                        className={`text-[9px] font-black uppercase ${
                          c.type === 'pendapatan' ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        {c.type}
                      </p>
                    </div>
                  </div>
                  {categories.length > 1 && (
                    <button
                      onClick={() => onDeleteCategory(c.id)}
                      className="p-2 text-slate-400 hover:text-red-400 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBVIEW: CURRENCY */}
        {subView === 'currency' && (
          <div className="space-y-2">
            {CURRENCY_LIST.map(c => {
              const isSelected = currency.code === c.code;
              return (
                <div
                  key={c.code}
                  onClick={() => {
                    onSelectCurrency(c);
                    onShowToast(`Mata uang diubah ke ${c.code}`);
                  }}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-blue-400">
                      {c.symbol}
                    </span>
                    <div>
                      <p className="font-bold text-xs">{c.name}</p>
                      <p className="text-[10px] text-slate-400">{c.code}</p>
                    </div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-blue-400" />}
                </div>
              );
            })}
          </div>
        )}

        {/* SUBVIEW: LANGUAGE */}
        {subView === 'language' && (
          <div className="space-y-2">
            {LANGUAGES_LIST.map(l => {
              const isSelected = language === l.code;
              return (
                <div
                  key={l.code}
                  onClick={() => {
                    onSelectLanguage(l.code);
                    onShowToast(`Bahasa diubah ke ${l.name}`);
                  }}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="font-bold text-xs">{l.name}</span>
                  {isSelected && <Check className="w-4 h-4 text-blue-400" />}
                </div>
              );
            })}
          </div>
        )}

        {/* SUBVIEW: THEME */}
        {subView === 'theme' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {(['dark', 'light', 'system'] as const).map(m => (
                <button
                  key={m}
                  onClick={() => {
                    onSelectDisplayMode(m);
                    onShowToast(`Mode tampilan diubah ke ${m}`);
                  }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition ${
                    displayMode === m
                      ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <Palette className="w-5 h-5" />
                  <span className="text-xs font-bold capitalize">{m}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* SUBVIEW: PRIVACY */}
        {subView === 'privacy' && (
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs leading-relaxed text-slate-300">
            <h3 className="font-black text-sm text-white">Privasi Terjamin & 100% Offline</h3>
            <p>
              MyMoney dirancang dengan arsitektur <i>Local-First</i>. Seluruh data keuangan, dompet, transaksi, target tabungan, dan catatan utang piutang Anda tersimpan 100% di penyimpanan internal perangkat Anda.
            </p>
            <p>
              Tidak ada data yang dikirim atau dipantau oleh server eksternal mana pun. Privasi keuangan Anda sepenuhnya menjadi milik Anda.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

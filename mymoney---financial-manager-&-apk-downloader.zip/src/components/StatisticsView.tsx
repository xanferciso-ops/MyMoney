import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Transaction, Category, Currency } from '../types';
import { formatCurrency } from '../utils/moneyLogic';
import { MONTHS_MAP } from '../utils/constants';

interface StatisticsViewProps {
  transactions: Transaction[];
  categories: Category[];
  currency: Currency;
  isBalanceVisible: boolean;
}

export const StatisticsView: React.FC<StatisticsViewProps> = ({
  transactions,
  categories,
  currency,
  isBalanceVisible
}) => {
  const [statDate, setStatDate] = useState<Date>(new Date());

  const year = statDate.getFullYear();
  const month = statDate.getMonth();
  const months = MONTHS_MAP['id'];

  const displayMoney = (num: number) => {
    if (!isBalanceVisible) return `${currency.symbol} •••••••`;
    return formatCurrency(num, currency.symbol);
  };

  let totalInc = 0;
  let totalExp = 0;
  const expMap: Record<number, number> = {};
  const incMap: Record<number, number> = {};

  transactions.forEach(t => {
    const d = new Date(t.date);
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (t.type === 'pengeluaran') {
        expMap[t.categoryId] = (expMap[t.categoryId] || 0) + t.amount;
        totalExp += t.amount;
      } else {
        incMap[t.categoryId] = (incMap[t.categoryId] || 0) + t.amount;
        totalInc += t.amount;
      }
    }
  });

  const buildChartData = (map: Record<number, number>) => {
    return Object.keys(map).map(catIdStr => {
      const catId = Number(catIdStr);
      const cat = categories.find(c => c.id === catId) || {
        name: 'Lainnya',
        color: '#64748b'
      };
      return {
        id: catId,
        name: cat.name,
        amount: map[catId],
        color: cat.color
      };
    });
  };

  const expData = buildChartData(expMap);
  const incData = buildChartData(incMap);

  // SVG Donut Generator
  const renderDonut = (items: Array<{ name: string; amount: number; color: string }>, total: number) => {
    const r = 38;
    const circum = 2 * Math.PI * r;
    if (total === 0 || items.length === 0) {
      return (
        <svg viewBox="0 0 100 100" className="w-28 h-28">
          <circle cx="50" cy="50" r={r} fill="transparent" stroke="#1e293b" strokeWidth="12" />
        </svg>
      );
    }

    let offset = 0;
    return (
      <svg viewBox="0 0 100 100" className="w-28 h-28 transform -rotate-90">
        {items
          .sort((a, b) => b.amount - a.amount)
          .map((item, idx) => {
            const pct = (item.amount / total) * 100;
            const strokeDash = (pct / 100) * circum;
            const currentOffset = offset;
            offset += strokeDash;
            return (
              <circle
                key={idx}
                cx="50"
                cy="50"
                r={r}
                fill="transparent"
                stroke={item.color}
                strokeWidth="12"
                strokeDasharray={`${strokeDash} ${circum}`}
                strokeDashoffset={-currentOffset}
              />
            );
          })}
      </svg>
    );
  };

  const renderCard = (
    title: string,
    items: Array<{ name: string; amount: number; color: string }>,
    totalAmount: number,
    label: string,
    totalColor: string
  ) => (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
      <h3 className="font-extrabold text-xs text-white">{title}</h3>
      <div className="flex items-center gap-5">
        <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
          {renderDonut(items, totalAmount)}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-1 pointer-events-none">
            <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider">{label}</span>
            <span className={`text-xs font-black truncate max-w-[80px] ${totalColor}`}>
              {displayMoney(totalAmount).replace(`${currency.symbol} `, '')}
            </span>
          </div>
        </div>

        <div className="flex-1 space-y-2 text-xs overflow-hidden">
          {items.length === 0 ? (
            <p className="text-[10px] text-slate-500">Belum ada data bulan ini.</p>
          ) : (
            items
              .sort((a, b) => b.amount - a.amount)
              .slice(0, 5)
              .map((it, idx) => {
                const pct = totalAmount ? Math.round((it.amount / totalAmount) * 100) : 0;
                return (
                  <div key={idx} className="flex justify-between items-center text-[11px]">
                    <div className="flex items-center gap-2 truncate pr-2">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: it.color }} />
                      <span className="text-slate-300 truncate">{it.name}</span>
                    </div>
                    <span className="font-bold text-slate-400 shrink-0">{pct}%</span>
                  </div>
                );
              })
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Month Navigation */}
      <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between sticky top-0 z-10">
        <button
          onClick={() => {
            const next = new Date(statDate);
            next.setMonth(next.getMonth() - 1);
            setStatDate(next);
          }}
          className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="font-black text-xs uppercase tracking-widest text-white">
          {months[month]} {year}
        </span>
        <button
          onClick={() => {
            const next = new Date(statDate);
            next.setMonth(next.getMonth() + 1);
            setStatDate(next);
          }}
          className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Total Cashflow */}
        {renderCard(
          'Arus Kas Total',
          [
            { name: 'Pendapatan', amount: totalInc, color: '#10B981' },
            { name: 'Pengeluaran', amount: totalExp, color: '#EF4444' }
          ],
          totalInc + totalExp,
          'TOTAL',
          'text-white'
        )}

        {/* Expenses */}
        {renderCard('Analisis Pengeluaran', expData, totalExp, 'KELUAR', 'text-red-400')}

        {/* Income */}
        {renderCard('Analisis Pendapatan', incData, totalInc, 'MASUK', 'text-emerald-400')}
      </div>
    </div>
  );
};

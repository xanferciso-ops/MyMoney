import React from 'react';
import { ArrowLeft, Copy, Edit3, Trash2 } from 'lucide-react';
import { Transaction, Category, Wallet, Currency } from '../types';
import { formatCurrency } from '../utils/moneyLogic';

interface TransactionDetailModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  currency: Currency;
  categories: Category[];
  wallets: Wallet[];
  onEdit: (tx: Transaction) => void;
  onCopy: (tx: Transaction) => void;
  onDelete: (id: number) => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  transaction,
  onClose,
  currency,
  categories,
  wallets,
  onEdit,
  onCopy,
  onDelete
}) => {
  if (!transaction) return null;

  const cat = categories.find(c => c.id === transaction.categoryId) || {
    name: 'Lainnya',
    icon: '📝',
    color: '#3B82F6',
    type: 'pengeluaran'
  };
  const wal = wallets.find(w => w.id === transaction.walletId) || {
    name: 'Dompet Utama',
    icon: '💵',
    color: '#3B82F6'
  };

  const isInc = transaction.type === 'pendapatan';
  const d = new Date(transaction.date);
  const dateFormatted = `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1)
    .toString()
    .padStart(2, '0')}/${d.getFullYear()} ${d.getHours().toString().padStart(2, '0')}:${d
    .getMinutes()
    .toString()
    .padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-[215] bg-slate-950 flex flex-col text-slate-100 animate-in fade-in duration-200">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <button
          onClick={onClose}
          aria-label="Kembali"
          className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
          Detail Transaksi
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onCopy(transaction)}
            title="Salin Transaksi"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300 transition"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button
            onClick={() => onEdit(transaction)}
            title="Ubah Transaksi"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-blue-400 transition"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(transaction.id)}
            title="Hapus Transaksi"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-red-400 transition"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-5 max-w-lg mx-auto w-full space-y-6">
        <div className="flex items-center gap-4 pt-4">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-xl shrink-0"
            style={{ backgroundColor: `${cat.color}25`, color: cat.color }}
          >
            {cat.icon}
          </div>
          <div>
            <h1 className="text-xl font-black text-white leading-tight">{transaction.note}</h1>
            <span
              className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                isInc
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}
            >
              {isInc ? 'Pendapatan' : 'Pengeluaran'}
            </span>
          </div>
        </div>

        {/* Info Card */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs divide-y divide-slate-800/80">
          <div className="flex justify-between items-center pb-2">
            <span className="text-slate-400 uppercase font-bold text-[10px] tracking-wider">Nominal</span>
            <span className={`text-xl font-black ${isInc ? 'text-emerald-400' : 'text-red-400'}`}>
              {isInc ? '+' : '-'}{formatCurrency(transaction.amount, currency.symbol)}
            </span>
          </div>

          <div className="flex justify-between items-center py-3">
            <span className="text-slate-400 uppercase font-bold text-[10px] tracking-wider">Kategori</span>
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>{cat.icon}</span>
              <span>{cat.name}</span>
            </span>
          </div>

          <div className="flex justify-between items-center py-3">
            <span className="text-slate-400 uppercase font-bold text-[10px] tracking-wider">Dompet</span>
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>{wal.icon}</span>
              <span>{wal.name}</span>
            </span>
          </div>

          <div className="flex justify-between items-center py-3">
            <span className="text-slate-400 uppercase font-bold text-[10px] tracking-wider">Waktu</span>
            <span className="font-bold text-slate-200">{dateFormatted}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

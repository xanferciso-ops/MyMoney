import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Inbox } from 'lucide-react';
import { Transaction, Category, Wallet, Currency } from '../types';
import { formatCurrency } from '../utils/moneyLogic';
import { MONTHS_MAP, DAYS_MAP } from '../utils/constants';

interface CalendarViewProps {
  transactions: Transaction[];
  categories: Category[];
  wallets: Wallet[];
  currency: Currency;
  isBalanceVisible: boolean;
  onOpenDetail: (tx: Transaction) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  transactions,
  categories,
  wallets,
  currency,
  isBalanceVisible,
  onOpenDetail
}) => {
  const [calDate, setCalDate] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date>(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const year = calDate.getFullYear();
  const month = calDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const months = MONTHS_MAP['id'];
  const days = DAYS_MAP['id'];

  const displayMoney = (num: number) => {
    if (!isBalanceVisible) return `${currency.symbol} •••••••`;
    return formatCurrency(num, currency.symbol);
  };

  // Day aggregations
  const daySummaryMap: Record<number, { inc: number; exp: number }> = {};
  transactions.forEach(t => {
    const d = new Date(t.date);
    if (d.getFullYear() === year && d.getMonth() === month) {
      const dd = d.getDate();
      if (!daySummaryMap[dd]) daySummaryMap[dd] = { inc: 0, exp: 0 };
      if (t.type === 'pendapatan') daySummaryMap[dd].inc += t.amount;
      else daySummaryMap[dd].exp += t.amount;
    }
  });

  // Selected date transactions
  const selectedDayTxs = transactions.filter(t => {
    const td = new Date(t.date);
    return (
      td.getDate() === selectedDate.getDate() &&
      td.getMonth() === selectedDate.getMonth() &&
      td.getFullYear() === selectedDate.getFullYear()
    );
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-4 pb-20">
      {/* Month Navigation */}
      <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between sticky top-0 z-10">
        <button
          onClick={() => {
            const next = new Date(calDate);
            next.setMonth(next.getMonth() - 1);
            setCalDate(next);
          }}
          className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="font-black text-xs uppercase tracking-widest text-white">
          {months[month]} {year}
        </span>
        <button
          onClick={() => {
            const next = new Date(calDate);
            next.setMonth(next.getMonth() + 1);
            setCalDate(next);
          }}
          className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Days of week header */}
      <div className="grid grid-cols-7 text-center py-2 bg-slate-950/60 border-b border-slate-800 text-[10px] font-black uppercase text-slate-400">
        <span className="text-red-400">{days[0]}</span>
        <span>{days[1]}</span>
        <span>{days[2]}</span>
        <span>{days[3]}</span>
        <span>{days[4]}</span>
        <span>{days[5]}</span>
        <span>{days[6]}</span>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 border-b border-slate-800/80 bg-slate-900/60">
        {/* Leading empty slots */}
        {Array.from({ length: firstDayIndex }).map((_, i) => (
          <div key={`empty-${i}`} className="min-h-[58px] border-b border-r border-slate-800/40 bg-slate-950/20" />
        ))}

        {/* Days */}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          const isSelected =
            selectedDate.getDate() === day &&
            selectedDate.getMonth() === month &&
            selectedDate.getFullYear() === year;

          const summary = daySummaryMap[day];

          return (
            <div
              key={`day-${day}`}
              onClick={() => {
                const newD = new Date(year, month, day);
                newD.setHours(0, 0, 0, 0);
                setSelectedDate(newD);
              }}
              className={`p-1 min-h-[58px] border-b border-r border-slate-800/60 flex flex-col justify-between cursor-pointer transition ${
                isSelected
                  ? 'bg-blue-600/20 border-blue-500'
                  : 'hover:bg-slate-800/50'
              }`}
            >
              <span
                className={`text-[10px] font-bold px-1 ${
                  isSelected ? 'text-blue-400 font-black' : 'text-slate-300'
                }`}
              >
                {day}
              </span>
              <div className="text-[8px] font-black text-right pr-0.5 space-y-0.5 leading-tight">
                {summary?.inc ? (
                  <span className="text-emerald-400 block truncate">
                    +{summary.inc >= 1000 ? `${Math.round(summary.inc / 1000)}k` : summary.inc}
                  </span>
                ) : null}
                {summary?.exp ? (
                  <span className="text-red-400 block truncate">
                    -{summary.exp >= 1000 ? `${Math.round(summary.exp / 1000)}k` : summary.exp}
                  </span>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Day Drilldown */}
      <div className="p-4 space-y-3">
        <div className="flex justify-between items-center pb-2 border-b border-slate-800">
          <div>
            <span className="text-lg font-black text-white mr-2">{selectedDate.getDate()}</span>
            <span className="text-xs text-slate-400 font-bold">
              {days[selectedDate.getDay()]}, {months[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </span>
          </div>
          <span className="text-xs text-slate-500 font-bold">{selectedDayTxs.length} Transaksi</span>
        </div>

        {selectedDayTxs.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Inbox className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-xs">Tidak ada transaksi pada tanggal ini.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {selectedDayTxs.map(t => {
              const c = categories.find(x => x.id === t.categoryId) || {
                name: 'Lainnya',
                icon: '📝',
                color: '#3B82F6'
              };
              const isInc = t.type === 'pendapatan';

              return (
                <div
                  key={t.id}
                  onClick={() => onOpenDetail(t)}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-between cursor-pointer transition shadow-sm"
                >
                  <div className="flex items-center gap-3 truncate pr-2">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
                      style={{ backgroundColor: `${c.color}20`, color: c.color }}
                    >
                      {c.icon}
                    </div>
                    <div className="truncate">
                      <p className="font-bold text-xs text-white truncate">{t.note}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{c.name}</p>
                    </div>
                  </div>

                  <span
                    className={`font-black text-xs shrink-0 ${
                      isInc ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {isInc ? '+' : '-'}
                    {displayMoney(t.amount)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

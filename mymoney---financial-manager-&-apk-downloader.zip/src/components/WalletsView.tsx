import React from 'react';
import { Plus, Wallet as WalletIcon, ChevronRight } from 'lucide-react';
import { Wallet, Transaction, Currency } from '../types';
import { formatCurrency } from '../utils/moneyLogic';

interface WalletsViewProps {
  wallets: Wallet[];
  transactions: Transaction[];
  currency: Currency;
  isBalanceVisible: boolean;
  onOpenSettingsWallets: () => void;
}

export const WalletsView: React.FC<WalletsViewProps> = ({
  wallets,
  transactions,
  currency,
  isBalanceVisible,
  onOpenSettingsWallets
}) => {
  const displayMoney = (num: number) => {
    if (!isBalanceVisible) return `${currency.symbol} •••••••`;
    return formatCurrency(num, currency.symbol);
  };

  return (
    <div className="p-4 space-y-4 pb-20">
      <div className="flex justify-between items-center">
        <h3 className="font-extrabold text-sm text-white">Akun & Sumber Dana</h3>
        <button
          onClick={onOpenSettingsWallets}
          className="text-xs font-bold text-blue-400 hover:text-blue-300 transition"
        >
          Kelola
        </button>
      </div>

      <div className="space-y-2.5">
        {wallets.map(w => {
          const sum = transactions
            .filter(t => t.walletId === w.id)
            .reduce((s, t) => s + (t.type === 'pendapatan' ? t.amount : -t.amount), 0);

          return (
            <div
              key={w.id}
              onClick={onOpenSettingsWallets}
              className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-between cursor-pointer transition shadow-sm"
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                  style={{ backgroundColor: `${w.color}20`, color: w.color }}
                >
                  {w.icon}
                </span>
                <div>
                  <p className="font-bold text-xs text-white">{w.name}</p>
                  <p className="text-[10px] text-slate-400">Akun Tersimpan</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-black text-xs text-white">{displayMoney(sum)}</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
              </div>
            </div>
          );
        })}

        <button
          onClick={onOpenSettingsWallets}
          className="w-full p-4 rounded-2xl border-2 border-dashed border-slate-800 hover:border-blue-500 flex items-center justify-center gap-2 text-slate-400 hover:text-blue-400 transition"
        >
          <Plus className="w-4 h-4" />
          <span className="text-xs font-bold">+ Tambah Akun Dompet Baru</span>
        </button>
      </div>
    </div>
  );
};

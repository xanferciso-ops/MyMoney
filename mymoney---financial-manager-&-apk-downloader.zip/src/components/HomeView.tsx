import React from 'react';
import { Plus, Inbox } from 'lucide-react';
import { Transaction, Category, Wallet, Currency } from '../types';
import { formatCurrency } from '../utils/moneyLogic';
import { MONTHS_MAP, DAYS_MAP } from '../utils/constants';

interface HomeViewProps {
  transactions: Transaction[];
  categories: Category[];
  wallets: Wallet[];
  currency: Currency;
  isBalanceVisible: boolean;
  onOpenDetail: (tx: Transaction) => void;
  onOpenAddTx: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  transactions,
  categories,
  wallets,
  currency,
  isBalanceVisible,
  onOpenDetail,
  onOpenAddTx
}) => {
  const displayMoney = (num: number) => {
    if (!isBalanceVisible) return `${currency.symbol} •••••••`;
    return formatCurrency(num, currency.symbol);
  };

  // Group transactions by day
  const group: Record<number, { date: Date; txs: Transaction[]; total: number }> = {};
  transactions.forEach(t => {
    const d = new Date(t.date);
    const dayKey = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    if (!group[dayKey]) group[dayKey] = { date: d, txs: [], total: 0 };
    group[dayKey].txs.push(t);
    group[dayKey].total += t.type === 'pendapatan' ? t.amount : -t.amount;
  });

  const sortedDays = Object.keys(group)
    .map(Number)
    .sort((a, b) => b - a);

  if (sortedDays.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center text-slate-400 min-h-[300px]">
        <div className="w-16 h-16 rounded-full bg-slate-800/80 flex items-center justify-center mb-3 text-slate-500">
          <Inbox className="w-8 h-8" />
        </div>
        <p className="font-bold text-sm text-slate-300">Belum ada catatan transaksi</p>
        <p className="text-xs text-slate-500 max-w-xs mt-1">
          Mulai catat pengeluaran dan pemasukan harian Anda dengan menekan tombol tambah (+) di bawah.
        </p>
        <button
          onClick={onOpenAddTx}
          className="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Transaksi Pertama</span>
        </button>
      </div>
    );
  }

  const months = MONTHS_MAP['id'];
  const days = DAYS_MAP['id'];

  return (
    <div className="space-y-4 pb-20">
      {sortedDays.map(key => {
        const g = group[key];
        const d = g.date;
        const hari = days[d.getDay()];
        const bulan = months[d.getMonth()]?.substring(0, 3) || '';

        return (
          <div key={key} className="space-y-2">
            {/* Day Header */}
            <div className="flex justify-between items-center px-4 py-2 text-xs border-b border-slate-800/80 bg-slate-950/40">
              <span className="font-black text-slate-200">
                {d.getDate()} {bulan} {d.getFullYear()}
              </span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-[10px] text-slate-400">{hari}</span>
                <span
                  className={`font-black text-xs ${
                    g.total >= 0 ? 'text-emerald-400' : 'text-slate-300'
                  }`}
                >
                  {g.total > 0 ? '+' : ''}
                  {displayMoney(g.total)}
                </span>
              </div>
            </div>

            {/* Day Transaction List */}
            <div className="px-3 space-y-2">
              {g.txs
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(t => {
                  const c = categories.find(x => x.id === t.categoryId) || {
                    name: 'Lainnya',
                    icon: '📝',
                    color: '#3B82F6'
                  };
                  const isInc = t.type === 'pendapatan';

                  return (
                    <div
                      key={t.id}
                      onClick={() => onOpenDetail(t)}
                      className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-slate-700 flex items-center justify-between cursor-pointer transition shadow-sm active:scale-[0.99]"
                    >
                      <div className="flex items-center gap-3 truncate pr-2">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
                          style={{ backgroundColor: `${c.color}20`, color: c.color }}
                        >
                          {c.icon}
                        </div>
                        <div className="truncate">
                          <p className="font-bold text-xs text-white truncate">{t.note}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">{c.name}</p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`font-black text-xs ${
                            isInc ? 'text-emerald-400' : 'text-slate-200'
                          }`}
                        >
                          {isInc ? '+' : '-'}
                          {displayMoney(t.amount)}
                        </span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

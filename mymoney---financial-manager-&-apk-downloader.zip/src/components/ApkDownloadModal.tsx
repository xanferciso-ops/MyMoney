import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';
import {
  Download,
  Share2,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  QrCode,
  ExternalLink,
  X,
  FileCheck,
  AlertCircle
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({
  isOpen,
  onClose,
  onShowToast
}) => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'apk' | 'share' | 'guide'>('apk');
  const { isInstallable, install, isIOS } = usePWAInstall();

  const downloadUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/MyMoney.apk`
    : '/MyMoney.apk';
  const appShareUrl = typeof window !== 'undefined'
    ? window.location.origin
    : 'https://ais-dev-p6y5tm6v6oonpkebudtj3p-215456627750.asia-northeast1.run.app';

  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(downloadUrl, {
        width: 220,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      })
        .then(url => setQrCodeUrl(url))
        .catch(err => console.error('QR code generation failed:', err));
    }
  }, [isOpen, downloadUrl]);

  if (!isOpen) return null;

  const handleDownloadApk = () => {
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.7 }
    });
    onShowToast('Memulai download MyMoney.apk...', 'success');

    // Trigger download
    const link = document.createElement('a');
    link.href = '/MyMoney.apk';
    link.download = 'MyMoney_v2.6.0.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(downloadUrl);
      setCopied(true);
      onShowToast('Tautan download APK berhasil disalin!', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onShowToast('Gagal menyalin tautan', 'error');
    }
  };

  const handleShareApp = async () => {
    const shareText = `Halo! Pasang aplikasi MyMoney Financial Manager di HP kamu untuk catat keuangan pribadi, hemat kuota dan 100% offline.\n\nDownload APK langsung di sini:\n${downloadUrl}\n\nAtau buka langsung di browser:\n${appShareUrl}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MyMoney - Financial Manager APK',
          text: shareText,
          url: downloadUrl
        });
        onShowToast('Berhasil membagikan tautan!', 'success');
      } catch (e: any) {
        if (e.name !== 'AbortError') {
          handleCopyLink();
        }
      }
    } else {
      // Fallback: WhatsApp share
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
      window.open(waUrl, '_blank');
      onShowToast('Membuka WhatsApp untuk membagikan...', 'success');
    }
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md max-h-[92vh] flex flex-col overflow-hidden shadow-2xl text-slate-100">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-blue-300 shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-black tracking-widest text-blue-300 uppercase block">
                DISTRIBUSI APLIKASI
              </span>
              <h2 className="text-base font-extrabold text-white">Download & Bagikan APK</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Tutup modal"
            className="w-9 h-9 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-3 p-2 bg-slate-950/60 border-b border-slate-800 text-xs font-bold gap-1">
          <button
            onClick={() => setActiveTab('apk')}
            className={`py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>
          <button
            onClick={() => setActiveTab('share')}
            className={`py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'share'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Bagikan / QR</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'guide'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Panduan</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {activeTab === 'apk' && (
            <div className="space-y-4">
              {/* APK Card Info */}
              <div className="p-4 rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-800/40 border border-slate-700">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src="/icon.svg"
                      alt="MyMoney Icon"
                      className="w-12 h-12 rounded-2xl shadow-lg border border-blue-500/30"
                    />
                    <div>
                      <h3 className="font-extrabold text-sm text-white">MyMoney.apk</h3>
                      <p className="text-[11px] text-blue-400 font-semibold">Versi 2.6.0 Pro Edition</p>
                      <span className="inline-block mt-0.5 px-2 py-0.5 rounded-full text-[9px] font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                        Siap Pasang di HP
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 py-2.5 border-y border-slate-700/60 my-3 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase font-bold">Ukuran File</span>
                    <span className="font-bold text-white">~45 KB</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase font-bold">Koneksi</span>
                    <span className="font-bold text-emerald-400">100% Offline</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase font-bold">Android</span>
                    <span className="font-bold text-white">5.0 s/d 14+</span>
                  </div>
                </div>

                <button
                  onClick={handleDownloadApk}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-sm shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transform active:scale-95 transition"
                >
                  <Download className="w-4 h-4" />
                  <span>Download APK Sekarang</span>
                </button>
              </div>

              {/* Install PWA Alternative */}
              {isInstallable && (
                <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-700/40 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Smartphone className="w-5 h-5 text-indigo-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Instal Langsung di Layar HP</p>
                      <p className="text-[10px] text-indigo-300">Tanpa download APK (PWA Web App)</p>
                    </div>
                  </div>
                  <button
                    onClick={install}
                    className="py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
                  >
                    Pasang
                  </button>
                </div>
              )}

              {/* Security Badge */}
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-[11px] text-slate-300">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>
                  File APK resmi telah ditandatangani digital (V1 & V2 signed). Aman dan bebas dari iklan berbahaya.
                </span>
              </div>
            </div>
          )}

          {activeTab === 'share' && (
            <div className="space-y-4 text-center">
              <div>
                <h3 className="font-extrabold text-sm text-white mb-1">Pindai QR Code di Handphone</h3>
                <p className="text-slate-400 text-[11px]">
                  Arahkan kamera HP teman Anda ke kode ini untuk langsung mendownload APK atau membuka aplikasi:
                </p>
              </div>

              {qrCodeUrl ? (
                <div className="inline-block p-3 rounded-2xl bg-white shadow-xl">
                  <img src={qrCodeUrl} alt="QR Code Download MyMoney" className="w-44 h-44 mx-auto" />
                </div>
              ) : (
                <div className="w-44 h-44 bg-slate-800 rounded-2xl mx-auto flex items-center justify-center text-slate-500">
                  <QrCode className="w-10 h-10 animate-pulse" />
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={handleShareApp}
                  className="py-3 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Kirim ke WhatsApp/Lain</span>
                </button>
                <button
                  onClick={handleCopyLink}
                  className="py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Tersalin!' : 'Salin Tautan'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-3">
              <h3 className="font-extrabold text-sm text-white">Cara Memasang APK di HP Android:</h3>
              <ol className="space-y-2.5 text-slate-300 text-[11px] pl-1">
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[10px] border border-blue-500/40">
                    1
                  </span>
                  <span>
                    Klik tombol <b>Download APK Sekarang</b> pada tab Download. File <code>MyMoney_v2.6.0.apk</code> akan tersimpan di HP.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[10px] border border-blue-500/40">
                    2
                  </span>
                  <span>
                    Buka panel notifikasi unduhan atau buka aplikasi <b>File Manager / Unduhan</b> di HP Anda.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[10px] border border-blue-500/40">
                    3
                  </span>
                  <span>
                    Tap file <b>MyMoney.apk</b>. Jika muncul dialog <i>"Demi keamanan, ponsel Anda tidak diizinkan memasang aplikasi dari sumber ini"</i>, tap <b>Setelan</b> lalu aktifkan <b>Izinkan dari sumber ini</b> (Allow from this source).
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[10px] border border-blue-500/40">
                    4
                  </span>
                  <span>
                    Tap <b>Install / Pasang</b>. Selesai! Ikon aplikasi MyMoney akan muncul di layar utama HP Anda.
                  </span>
                </li>
              </ol>

              {isIOS && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 flex items-start gap-2 mt-4 text-[11px]">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    <b>Pengguna iPhone / iOS:</b> File APK khusus untuk Android. Untuk iOS, tap tombol <b>Share</b> di Safari lalu pilih <b>Add to Home Screen</b>.
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-[11px]">
          <span className="text-slate-400 font-medium">Bisa dibagikan via WhatsApp, Bluetooth & Tautan</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { X, Calendar, Wallet as WalletIcon, Check, Plus } from 'lucide-react';
import { Category, Wallet, Currency, Transaction } from '../types';
import { parseNominal } from '../utils/moneyLogic';

interface TransactionFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  categories: Category[];
  wallets: Wallet[];
  editTransaction?: Transaction | null;
  onSave: (tx: {
    id?: number;
    type: 'pendapatan' | 'pengeluaran';
    amount: number;
    note: string;
    categoryId: number;
    walletId: number;
    date: string;
  }) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const TransactionFormModal: React.FC<TransactionFormModalProps> = ({
  isOpen,
  onClose,
  currency,
  categories,
  wallets,
  editTransaction,
  onSave,
  onShowToast
}) => {
  const [txType, setTxType] = useState<'pengeluaran' | 'pendapatan'>('pengeluaran');
  const [nominalStr, setNominalStr] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [selectedCatId, setSelectedCatId] = useState<number | null>(null);
  const [selectedWalletId, setSelectedWalletId] = useState<number>(wallets[0]?.id || 101);
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      if (editTransaction) {
        setTxType(editTransaction.type === 'pendapatan' ? 'pendapatan' : 'pengeluaran');
        setNominalStr(editTransaction.amount.toLocaleString('id-ID'));
        setNote(editTransaction.note);
        setSelectedCatId(editTransaction.categoryId);
        setSelectedWalletId(editTransaction.walletId);
        const d = new Date(editTransaction.date);
        d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
        setDateStr(d.toISOString().slice(0, 16));
      } else {
        setTxType('pengeluaran');
        setNominalStr('');
        setNote('');
        const firstMatchingCat = categories.find(c => c.type === 'pengeluaran');
        setSelectedCatId(firstMatchingCat ? firstMatchingCat.id : null);
        setSelectedWalletId(wallets[0]?.id || 101);
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        setDateStr(now.toISOString().slice(0, 16));
      }
    }
  }, [isOpen, editTransaction, categories, wallets]);

  if (!isOpen) return null;

  const handleTypeChange = (type: 'pengeluaran' | 'pendapatan') => {
    setTxType(type);
    const currCat = categories.find(c => c.id === selectedCatId);
    if (!currCat || currCat.type !== type) {
      const firstMatching = categories.find(c => c.type === type);
      setSelectedCatId(firstMatching ? firstMatching.id : null);
    }
  };

  const handleAddNominal = (addVal: number) => {
    const curr = parseNominal(nominalStr);
    const updated = curr + addVal;
    setNominalStr(updated.toLocaleString('id-ID'));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseNominal(nominalStr);
    if (amount <= 0) {
      onShowToast('Nominal harus lebih dari 0!', 'error');
      return;
    }
    if (!selectedCatId) {
      onShowToast('Pilih kategori transaksi!', 'error');
      return;
    }

    const cat = categories.find(c => c.id === selectedCatId);
    onSave({
      id: editTransaction ? editTransaction.id : undefined,
      type: txType,
      amount,
      note: note.trim() || cat?.name || 'Transaksi',
      categoryId: selectedCatId,
      walletId: selectedWalletId,
      date: dateStr ? new Date(dateStr).toISOString() : new Date().toISOString()
    });

    onClose();
  };

  const filteredCategories = categories.filter(c => c.type === txType);

  return (
    <div className="fixed inset-0 z-[210] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl w-full max-w-lg max-h-[92vh] flex flex-col overflow-hidden shadow-2xl text-slate-100">
        
        {/* Header */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Type Toggle */}
          <div className="flex bg-slate-950 p-1 rounded-full border border-slate-800 text-xs font-bold gap-1">
            <button
              type="button"
              onClick={() => handleTypeChange('pengeluaran')}
              className={`px-4 py-1.5 rounded-full transition ${
                txType === 'pengeluaran'
                  ? 'bg-red-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pengeluaran
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('pendapatan')}
              className={`px-4 py-1.5 rounded-full transition ${
                txType === 'pendapatan'
                  ? 'bg-emerald-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pendapatan
            </button>
          </div>

          <button
            type="button"
            onClick={handleSubmit}
            className="text-blue-400 hover:text-blue-300 font-black text-xs uppercase tracking-wider px-2 py-1"
          >
            SIMPAN
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Nominal */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">
              Nominal Uang
            </label>
            <div className="flex items-center p-3 rounded-2xl bg-slate-950 border border-slate-800 focus-within:border-blue-500 transition">
              <span className="text-xl font-black text-slate-400 mr-2">{currency.symbol}</span>
              <input
                type="text"
                inputMode="numeric"
                value={nominalStr}
                onChange={e => {
                  const val = e.target.value.replace(/\D/g, '');
                  setNominalStr(val ? parseInt(val, 10).toLocaleString('id-ID') : '');
                }}
                placeholder="0"
                autoFocus
                className="w-full bg-transparent text-3xl font-black text-white outline-none"
              />
            </div>

            {/* Quick shortcuts */}
            <div className="grid grid-cols-4 gap-2 mt-2">
              {[10000, 20000, 50000, 100000].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleAddNominal(val)}
                  className="py-1.5 px-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition"
                >
                  +{val >= 1000 ? `${val / 1000}rb` : val}
                </button>
              ))}
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">
              Catatan Transaksi
            </label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Misal: Makan Siang, Beli Bensin, Gaji..."
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-white outline-none focus:border-blue-500 transition"
            />
          </div>

          {/* Categories */}
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-2">
              Pilih Kategori ({filteredCategories.length})
            </label>
            <div className="grid grid-cols-4 gap-2">
              {filteredCategories.map(c => {
                const isSelected = selectedCatId === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setSelectedCatId(c.id)}
                    className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center transition cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600/25 border-blue-500 shadow-md'
                        : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-xl mb-1">{c.icon}</span>
                    <span className="text-[10px] font-bold text-slate-200 truncate w-full text-center">
                      {c.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Wallet */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">
                Tanggal & Waktu
              </label>
              <input
                type="datetime-local"
                value={dateStr}
                onChange={e => setDateStr(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none font-bold"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">
                Pilih Dompet
              </label>
              <select
                value={selectedWalletId}
                onChange={e => setSelectedWalletId(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none font-bold"
              >
                {wallets.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.icon} {w.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <button
            type="button"
            onClick={handleSubmit}
            className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-lg shadow-blue-500/30 uppercase tracking-wider transition"
          >
            {editTransaction ? 'Perbarui Transaksi' : 'Simpan Transaksi'}
          </button>
        </div>

      </div>
    </div>
  );
};

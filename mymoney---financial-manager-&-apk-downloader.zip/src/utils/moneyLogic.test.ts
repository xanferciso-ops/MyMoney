import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseNominal,
  formatCurrency,
  calculateTotalBalance,
  calculateMonthlyTotals,
  calculateDailyAverage,
  calculateGoalProgress,
  calculateNextBillDueDate,
  type Transaction
} from './moneyLogic';

test('parseNominal parses string numbers with dots or symbols safely', () => {
  assert.equal(parseNominal('50.000'), 50000);
  assert.equal(parseNominal('Rp 1.500.000'), 1500000);
  assert.equal(parseNominal(''), 0);
  assert.equal(parseNominal(null), 0);
});

test('formatCurrency formats Indonesian currency format', () => {
  assert.equal(formatCurrency(50000, 'Rp'), 'Rp 50.000');
  assert.equal(formatCurrency(-25000, 'Rp'), '-Rp 25.000');
});

test('calculateTotalBalance computes net balance correctly', () => {
  const txs: Transaction[] = [
    { id: 1, type: 'pendapatan', amount: 5000000, note: 'Gaji', categoryId: 1, walletId: 1, date: '2026-10-01' },
    { id: 2, type: 'pengeluaran', amount: 500000, note: 'Belanja', categoryId: 2, walletId: 1, date: '2026-10-02' },
    { id: 3, type: 'pengeluaran', amount: 200000, note: 'Bensin', categoryId: 3, walletId: 1, date: '2026-10-03' }
  ];
  assert.equal(calculateTotalBalance(txs), 4300000);
});

test('calculateMonthlyTotals filters only given month and year', () => {
  const txs: Transaction[] = [
    { id: 1, type: 'pendapatan', amount: 1000000, note: 'Okt Inc', categoryId: 1, walletId: 1, date: '2026-10-05' },
    { id: 2, type: 'pengeluaran', amount: 400000, note: 'Okt Exp', categoryId: 2, walletId: 1, date: '2026-10-06' },
    { id: 3, type: 'pendapatan', amount: 999999, note: 'Sept Inc', categoryId: 1, walletId: 1, date: '2026-09-10' }
  ];
  const oct = calculateMonthlyTotals(txs, 2026, 9); // October is month index 9 in JS Date
  assert.equal(oct.income, 1000000);
  assert.equal(oct.expense, 400000);
  assert.equal(oct.net, 600000);
});

test('calculateDailyAverage computes proper round integer', () => {
  assert.equal(calculateDailyAverage(300000, 10), 30000);
  assert.equal(calculateDailyAverage(100000, 0), 100000);
});

test('calculateGoalProgress caps between 0 and 100', () => {
  assert.equal(calculateGoalProgress(1000000, 500000), 50);
  assert.equal(calculateGoalProgress(1000000, 1200000), 100);
});

test('calculateNextBillDueDate adds correct cycle interval', () => {
  assert.equal(calculateNextBillDueDate('2026-10-10', 'Mingguan'), '2026-10-17');
  assert.equal(calculateNextBillDueDate('2026-10-10', 'Bulanan'), '2026-11-10');
  assert.equal(calculateNextBillDueDate('2026-10-10', 'Tahunan'), '2027-10-10');
});

/**
 * Pure business logic for MyMoney financial calculations
 */

export interface Transaction {
  id: number;
  type: 'pendapatan' | 'pengeluaran' | 'pro';
  amount: number;
  note: string;
  categoryId: number;
  walletId: number;
  date: string;
}

export interface Budget {
  catId: number | string;
  limit: number;
}

export interface Goal {
  name: string;
  target: number;
  saved: number;
  date?: string;
}

export interface Bill {
  name: string;
  amount: number;
  due?: string;
  cycle: 'Mingguan' | 'Bulanan' | 'Tahunan';
}

export function parseNominal(val: string | number | null | undefined): number {
  if (!val) return 0;
  if (typeof val === 'number') return Math.max(0, Math.floor(val));
  const cleaned = String(val).replace(/\D/g, '');
  return parseInt(cleaned, 10) || 0;
}

export function formatCurrency(amount: number, symbol: string = 'Rp'): string {
  const isNegative = amount < 0;
  const absVal = Math.abs(amount);
  return (isNegative ? '-' : '') + symbol + ' ' + absVal.toLocaleString('id-ID');
}

export function calculateTotalBalance(transactions: Transaction[]): number {
  return transactions.reduce((acc, tx) => {
    return acc + (tx.type === 'pendapatan' ? tx.amount : -tx.amount);
  }, 0);
}

export function calculateMonthlyTotals(
  transactions: Transaction[],
  year: number,
  month: number
): { income: number; expense: number; net: number } {
  let income = 0;
  let expense = 0;

  for (const tx of transactions) {
    const d = new Date(tx.date);
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (tx.type === 'pendapatan') {
        income += tx.amount;
      } else {
        expense += tx.amount;
      }
    }
  }

  return { income, expense, net: income - expense };
}

export function calculateDailyAverage(
  totalExpense: number,
  daysPassed: number
): number {
  const validDays = Math.max(1, daysPassed);
  return Math.round(totalExpense / validDays);
}

export function calculateGoalProgress(target: number, saved: number): number {
  if (target <= 0) return 100;
  return Math.min(100, Math.max(0, Math.round((saved / target) * 100)));
}

export function calculateNextBillDueDate(currentDueDateStr: string, cycle: 'Mingguan' | 'Bulanan' | 'Tahunan'): string {
  if (!currentDueDateStr) return '';
  const d = new Date(currentDueDateStr + 'T12:00:00');
  if (isNaN(d.getTime())) return currentDueDateStr;

  if (cycle === 'Mingguan') {
    d.setDate(d.getDate() + 7);
  } else if (cycle === 'Bulanan') {
    d.setMonth(d.getMonth() + 1);
  } else if (cycle === 'Tahunan') {
    d.setFullYear(d.getFullYear() + 1);
  }

  return d.toISOString().slice(0, 10);
}

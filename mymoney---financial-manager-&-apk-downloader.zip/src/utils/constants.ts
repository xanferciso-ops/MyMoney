import { Category, Wallet, Currency } from '../types';

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 1, name: 'Makanan & Minuman', icon: '🍔', type: 'pengeluaran', color: '#F59E0B' },
  { id: 2, name: 'Transportasi', icon: '🚗', type: 'pengeluaran', color: '#3B82F6' },
  { id: 3, name: 'Belanja Harian', icon: '🛒', type: 'pengeluaran', color: '#EC4899' },
  { id: 4, name: 'Hiburan & Hobi', icon: '🍿', type: 'pengeluaran', color: '#8B5CF6' },
  { id: 5, name: 'Tagihan & Usaha', icon: '💡', type: 'pengeluaran', color: '#06B6D4' },
  { id: 6, name: 'Kesehatan', icon: '💊', type: 'pengeluaran', color: '#10B981' },
  { id: 7, name: 'Gaji Utama', icon: '💰', type: 'pendapatan', color: '#10B981' },
  { id: 8, name: 'Project / Freelance', icon: '💼', type: 'pendapatan', color: '#8B5CF6' },
  { id: 9, name: 'Bonus & Cashback', icon: '🎁', type: 'pendapatan', color: '#F43F5E' }
];

export const DEFAULT_WALLETS: Wallet[] = [
  { id: 101, name: 'Tunai (Dompet Utama)', icon: '💵', color: '#EF4444' },
  { id: 102, name: 'Rekening BCA', icon: '🏦', color: '#3B82F6' },
  { id: 103, name: 'GoPay / OVO', icon: '📱', color: '#10B981' },
  { id: 104, name: 'Tabungan Jenius', icon: '💳', color: '#8B5CF6' }
];

export const CURRENCY_LIST: Currency[] = [
  { code: 'IDR', symbol: 'Rp', name: 'Rupiah Indonesia (Rp)' },
  { code: 'USD', symbol: '$', name: 'Dolar Amerika ($)' },
  { code: 'EUR', symbol: '€', name: 'Euro (€)' },
  { code: 'CNY', symbol: '¥', name: 'Yuan China (¥)' },
  { code: 'INR', symbol: '₹', name: 'Rupee India (₹)' },
  { code: 'GBP', symbol: '£', name: 'Poundsterling Inggris (£)' },
  { code: 'KRW', symbol: '₩', name: 'Won Korea Selatan (₩)' },
  { code: 'JPY', symbol: '¥', name: 'Yen Jepang (¥)' },
  { code: 'SGD', symbol: 'S$', name: 'Dolar Singapura (S$)' },
  { code: 'MYR', symbol: 'RM', name: 'Ringgit Malaysia (RM)' },
  { code: 'SAR', symbol: 'SR', name: 'Riyal Arab Saudi (SR)' },
  { code: 'AED', symbol: 'AED', name: 'Dirham UEA (AED)' }
];

export const LANGUAGES_LIST = [
  { code: 'id', name: 'Bahasa Indonesia 🇮🇩' },
  { code: 'en', name: 'English 🇺🇸' },
  { code: 'ms', name: 'Bahasa Melayu 🇲🇾' },
  { code: 'zh', name: '中文 (Chinese) 🇨🇳' },
  { code: 'ja', name: '日本語 (Japanese) 🇯🇵' }
];

export const MONTHS_MAP: Record<string, string[]> = {
  id: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
};

export const DAYS_MAP: Record<string, string[]> = {
  id: ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'],
  en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
};

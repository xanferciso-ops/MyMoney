// PWA Service Worker Registration
import { registerSW } from 'virtual:pwa-register';

if (typeof window !== 'undefined') {
  registerSW({
    immediate: true,
    onNeedRefresh() {
      console.log('MyMoney update available');
    },
    onOfflineReady() {
      console.log('MyMoney is ready for offline use');
    },
  });
}

import re

def main():
    with open('public/assets/aistudio/MyMoney_aplikasi_keuangan__1__0594377b.html', 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Update theme CSS (ensuring Light mode is crisp white #FFFFFF and soft #F4F7FC)
    old_style_target = """        .theme-light {
            --bg-main: #F4F7FC;
            --bg-card: #FFFFFF;
            --bg-sub: #F8FAFC;
            --border-main: rgba(226, 232, 240, 0.6);
            --border-card: #F1F5F9;
            --text-main: #1E293B;
            --text-sub: #64748B;
        }"""

    new_style_replacement = """        .theme-light {
            --bg-main: #F4F7FC;
            --bg-card: #FFFFFF;
            --bg-sub: #F8FAFC;
            --border-main: rgba(203, 213, 225, 0.8);
            --border-card: #E2E8F0;
            --text-main: #0F172A;
            --text-sub: #475569;
        }

        .theme-light.app-container {
            border-color: #CBD5E1 !important;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15) !important;
        }

        .theme-light .input-dark,
        .theme-light .px-input {
            background-color: #FFFFFF !important;
            color: #0F172A !important;
            border: 1px solid #CBD5E1 !important;
        }

        .theme-light #settings-screen,
        .theme-light #sub-settings-modal,
        .theme-light #detail-modal,
        .theme-light #premium-modal {
            background-color: #F4F7FC !important;
            color: #0F172A !important;
        }

        .theme-light #premium-modal .px-head {
            background: linear-gradient(135deg, #1e3a8a, #2563eb) !important;
            color: #FFFFFF !important;
        }

        .theme-light .px-card {
            background-color: #FFFFFF !important;
            border-color: #E2E8F0 !important;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04) !important;
        }"""

    if old_style_target in html:
        html = html.replace(old_style_target, new_style_replacement)
        print('Theme CSS updated successfully')

    # 2. Add typography scaling for better legibility
    scaling_css = """
        /* Typography Scaling for Enhanced Mobile Legibility */
        html { font-size: 15px; }
        
        .px-nav-btn {
            font-size: 11px !important;
            padding: 9px 5px !important;
        }
        .px-nav-btn i {
            font-size: 16px !important;
            margin-bottom: 4px !important;
        }
        .px-card h3 {
            font-size: 14px !important;
        }
        .px-muted {
            font-size: 12px !important;
        }
        .px-input {
            font-size: 13px !important;
            padding: 11px 13px !important;
        }
        .px-btn {
            font-size: 12px !important;
            padding: 11px 15px !important;
        }
        .px-row {
            font-size: 13px !important;
        }
    """
    html = html.replace('</style>', scaling_css + '\n    </style>')

    # 3. Add Web-Only Smart Download Bar inside #app-frame (Hidden when in APK via protocol check)
    target_app_frame = '<div class="app-container theme-dark" id="app-frame">'
    smart_download_bar = """<div class="app-container theme-dark" id="app-frame">
        <!-- Smart Web-Only APK Download Banner (Auto-hidden inside Android APK) -->
        <div id="web-apk-download-bar" style="display:none;background:linear-gradient(135deg, #2563eb, #4f46e5);color:#ffffff;padding:12px 16px;text-align:center;font-size:13px;font-weight:800;border-bottom:1px solid rgba(255,255,255,0.2);cursor:pointer;align-items:center;justify-content:center;gap:8px" onclick="downloadApkFile()">
            <i class="fas fa-download text-emerald-300"></i>
            <span>DOWNLOAD APK ANDROID (45 KB)</span>
            <span style="background:rgba(255,255,255,0.25);padding:2px 8px;border-radius:99px;font-size:10px;font-weight:700">KLIK DISINI</span>
        </div>"""
    
    if target_app_frame in html:
        html = html.replace(target_app_frame, smart_download_bar)
        print('Smart download bar added')

    # 4. Enhance applyThemeMode & add downloadApkFile
    old_theme_func = """        function applyThemeMode() {
            const frame = document.getElementById('app-frame');
            let isDark = true;
            if(appDisplayMode === 'dark') {
                isDark = true;
            } else if(appDisplayMode === 'light') {
                isDark = false;
            } else {
                isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            }

            if(isDark) {
                frame.classList.remove('theme-light');
                frame.classList.add('theme-dark');
            } else {
                frame.classList.remove('theme-dark');
                frame.classList.add('theme-light');
            }
        }"""

    new_theme_func = """        function applyThemeMode() {
            const frame = document.getElementById('app-frame');
            if(!frame) return;
            let isDark = true;
            if(appDisplayMode === 'dark') {
                isDark = true;
            } else if(appDisplayMode === 'light') {
                isDark = false;
            } else {
                isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            }

            if(isDark) {
                frame.classList.remove('theme-light');
                frame.classList.add('theme-dark');
                document.body.style.backgroundColor = '#090d16';
            } else {
                frame.classList.remove('theme-dark');
                frame.classList.add('theme-light');
                document.body.style.backgroundColor = '#E2E8F0';
            }
        }

        function downloadApkFile() {
            showToast("Mengunduh MyMoney.apk...", "success");
            fetch('/MyMoney.apk')
                .then(function(res) {
                    if (!res.ok) throw new Error("HTTP error " + res.status);
                    return res.blob();
                })
                .then(function(blob) {
                    var apkBlob = new Blob([blob], { type: 'application/vnd.android.package-archive' });
                    var url = window.URL.createObjectURL(apkBlob);
                    var a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.download = 'MyMoney.apk';
                    document.body.appendChild(a);
                    a.click();
                    setTimeout(function() {
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(a);
                    }, 2000);
                    showToast("MyMoney.apk berhasil diunduh!", "success");
                })
                .catch(function(err) {
                    var a = document.createElement('a');
                    a.href = '/MyMoney.apk';
                    a.download = 'MyMoney.apk';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                });
        }"""

    if old_theme_func in html:
        html = html.replace(old_theme_func, new_theme_func)
        print('Enhanced applyThemeMode & added downloadApkFile')

    # 5. In initApp(), show the download bar ONLY when NOT running in Android APK WebView (protocol !== 'file:')
    old_init = """        function initApp() {
            applyAccentColor(appTheme);
            applyThemeMode();
            applyLanguageToStaticUI();
            updateCurrencyLabels();
            updateGreeting();
            updateView();"""

    new_init = """        function initApp() {
            applyAccentColor(appTheme);
            applyThemeMode();
            applyLanguageToStaticUI();
            updateCurrencyLabels();
            updateGreeting();
            updateView();

            // Tampilkan tombol unduh HANYA di web preview (hilang 100% saat di dalam APK Android)
            if (window.location.protocol !== 'file:' && !navigator.userAgent.includes('wv')) {
                var webBar = document.getElementById('web-apk-download-bar');
                if (webBar) webBar.style.display = 'flex';
            }"""

    if old_init in html:
        html = html.replace(old_init, new_init)
        print('Conditional download bar check in initApp added')

    # 6. Scaling fonts in Header, Balance, Bottom Nav
    html = html.replace('text-[11px] text-app-sub font-medium mb-0.5', 'text-[12.5px] text-app-sub font-semibold mb-0.5')
    html = html.replace('text-lg font-bold text-app-main">Pengguna', 'text-xl font-extrabold text-app-main">Pengguna')
    html = html.replace('text-[11px] font-medium text-white/80" id="lbl-total-balance"', 'text-[12.5px] font-semibold text-white/90" id="lbl-total-balance"')
    html = html.replace('text-3xl font-black tracking-tight" id="header-balance"', 'text-[32px] font-black tracking-tight" id="header-balance"')
    html = html.replace('text-[10px] text-white/80 mt-1.5 font-medium flex items-center gap-1', 'text-[12px] text-white/90 mt-1.5 font-medium flex items-center gap-1.5')
    html = html.replace('text-[10px] font-bold tracking-wide">PUSAT PRO</span>', 'text-[11px] font-extrabold tracking-wide">PUSAT PRO</span>')

    # Bottom Nav
    html = html.replace('text-[10px] text-app-sub font-medium h-[90px]', 'text-[11px] text-app-sub font-semibold h-[92px]')
    html = html.replace('text-[20px] mb-1', 'text-[22px] mb-1')

    # Calendar View Scaling
    html = html.replace('text-xs font-black text-app-main tracking-widest uppercase">${monthsList[m]} ${y}</h3>', 'text-sm font-black text-app-main tracking-widest uppercase">${monthsList[m]} ${y}</h3>')
    html = html.replace('text-[8px] font-black text-app-sub uppercase tracking-widest', 'text-[10px] font-black text-app-sub uppercase tracking-widest')
    html = html.replace('text-[9px] font-black px-1 ${isT || isSel ? \'text-accent\' : \'text-app-sub\'}', 'text-[11px] font-black px-1 ${isT || isSel ? \'text-accent\' : \'text-app-sub\'}')
    html = html.replace('text-[7px] font-black text-right leading-tight pr-0.5 pb-0.5 space-y-0.5', 'text-[9px] font-black text-right leading-tight pr-0.5 pb-0.5 space-y-0.5')
    html = html.replace('text-2xl font-black text-app-main leading-none">${d.toString().padStart(2,\'0\')}</span>', 'text-3xl font-black text-app-main leading-none">${d.toString().padStart(2,\'0\')}</span>')
    html = html.replace('text-[9px] font-bold text-app-sub uppercase tracking-wide">${hari}</span>', 'text-[11px] font-bold text-app-sub uppercase tracking-wide">${hari}</span>')
    html = html.replace('text-[8px] text-app-sub font-bold">${bulan} ${y}</span>', 'text-[10px] text-app-sub font-bold">${bulan} ${y}</span>')
    html = html.replace('text-center mt-8 text-app-sub font-bold text-xs', 'text-center mt-8 text-app-sub font-bold text-sm')

    # Transactions list scaling
    html = html.replace('text-xs font-bold text-app-main">${d.getDate()} ${b} ${d.getFullYear()}</span>', 'text-sm font-bold text-app-main">${d.getDate()} ${b} ${d.getFullYear()}</span>')
    html = html.replace('text-[10px] font-bold text-app-sub">${hari}</span>', 'text-xs font-bold text-app-sub">${hari}</span>')
    html = html.replace('font-bold text-app-main text-xs truncate">${t.note}</h4>', 'font-bold text-app-main text-[13.5px] truncate">${t.note}</h4>')
    html = html.replace('text-[9px] text-app-sub font-medium">${c.name}</span>', 'text-[11px] text-app-sub font-medium">${c.name}</span>')
    html = html.replace('text-xs font-bold ${isInc?\'text-green-500\':\'text-app-main\'}', 'text-sm font-bold ${isInc?\'text-green-500\':\'text-app-main\'}')

    # Settings scaling
    html = html.replace('text-[10px] font-black text-app-sub uppercase tracking-widest', 'text-[11.5px] font-black text-app-sub uppercase tracking-widest')
    html = html.replace('text-sm font-bold text-app-main', 'text-[15px] font-bold text-app-main')
    html = html.replace('text-[10px] text-app-sub font-medium', 'text-[12px] text-app-sub font-medium')
    html = html.replace('text-[10px] text-accent font-medium', 'text-[12px] text-accent font-semibold')

    # Meta tags & script
    pwa_meta = """    <link rel="icon" type="image/svg+xml" href="/icon.svg">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    <meta name="theme-color" content="#090d16">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">"""

    if '<meta name="theme-color"' not in html:
        html = html.replace('</head>', pwa_meta + '\n</head>')

    if '<script type="module" src="/src/main.tsx"></script>' not in html:
        html = html.replace('</body>', '    <script type="module" src="/src/main.tsx"></script>\n</body>')

    with open('index.html', 'w', encoding='utf-8') as f:
        f.write(html)
    print('Generated index.html successfully')

if __name__ == '__main__':
    main()

#!/usr/bin/env bash
set -e

echo "=== Memulai Build MyMoney Android APK (Widget Fix & Cleanup) ==="

WORKDIR="/tmp/mymoney_apk_build"
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR/src/com/tpex/mymoney"
mkdir -p "$WORKDIR/res/values"
mkdir -p "$WORKDIR/res/xml"
mkdir -p "$WORKDIR/res/layout"
mkdir -p "$WORKDIR/res/drawable"
mkdir -p "$WORKDIR/res/mipmap-mdpi"
mkdir -p "$WORKDIR/res/mipmap-hdpi"
mkdir -p "$WORKDIR/res/mipmap-xhdpi"
mkdir -p "$WORKDIR/res/mipmap-xxhdpi"
mkdir -p "$WORKDIR/res/mipmap-xxxhdpi"
mkdir -p "$WORKDIR/assets"
mkdir -p "$WORKDIR/bin/classes"
mkdir -p "/app/applet/public/downloads"
mkdir -p "/app/applet/dist"

ANDROID_JAR="/usr/lib/android-sdk/platforms/android-23/android.jar"
DX="/usr/lib/android-sdk/build-tools/debian/dx"

# 1. AndroidManifest.xml (Activity + AppWidgetProvider)
cat << 'EOF' > "$WORKDIR/AndroidManifest.xml"
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.tpex.mymoney"
    android:versionCode="300"
    android:versionName="3.0.0 (Official Icon Edition)">

    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="28" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:theme="@style/AppTheme"
        android:hardwareAccelerated="true"
        android:allowBackup="true"
        android:supportsRtl="true">

        <activity
            android:name=".MainActivity"
            android:label="@string/app_name"
            android:configChanges="orientation|keyboardHidden|screenSize"
            android:screenOrientation="portrait"
            android:exported="true"
            android:launchMode="singleTop"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <intent-filter>
                <action android:name="com.tpex.mymoney.ACTION_ADD_TX" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="mymoney" android:host="addTx" />
            </intent-filter>
        </activity>

        <!-- PRD: Android App Widget Provider "MyMoney Quick Record" -->
        <receiver
            android:name=".QuickRecordWidgetProvider"
            android:label="@string/widget_name"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/quick_record_widget_info" />
        </receiver>

    </application>
</manifest>
EOF

# 2. Strings & Styles
cat << 'EOF' > "$WORKDIR/res/values/strings.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">MyMoney</string>
    <string name="widget_name">MyMoney Quick Record</string>
</resources>
EOF

cat << 'EOF' > "$WORKDIR/res/values/styles.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="@android:style/Theme.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:windowNoTitle">true</item>
    </style>
</resources>
EOF

# 3. Widget Meta & Drawables
cat << 'EOF' > "$WORKDIR/res/xml/quick_record_widget_info.xml"
<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="180dp"
    android:minHeight="40dp"
    android:updatePeriodMillis="86400000"
    android:initialLayout="@layout/widget_layout"
    android:previewImage="@drawable/widget_preview"
    android:resizeMode="horizontal"
    android:widgetCategory="home_screen">
</appwidget-provider>
EOF

cat << 'EOF' > "$WORKDIR/res/drawable/widget_capsule_bg.xml"
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <corners android:radius="26dp" />
    <solid android:color="#0F172A" />
    <stroke android:width="1dp" android:color="#334155" />
</shape>
EOF

cat << 'EOF' > "$WORKDIR/res/drawable/widget_brand_bg.xml"
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <corners android:topLeftRadius="24dp" android:bottomLeftRadius="24dp" android:topRightRadius="6dp" android:bottomRightRadius="6dp" />
    <gradient android:startColor="#2563EB" android:endColor="#3B82F6" android:angle="45" />
</shape>
EOF

cat << 'EOF' > "$WORKDIR/res/drawable/widget_actions_bg.xml"
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <corners android:topLeftRadius="6dp" android:bottomLeftRadius="6dp" android:topRightRadius="24dp" android:bottomRightRadius="24dp" />
    <solid android:color="#1E293B" />
</shape>
EOF

# 4. Layout XML: widget_layout.xml (RESTRIKSI KETAT: RemoteViews Hanya Mendukung Layout Whitelist)
cat << 'EOF' > "$WORKDIR/res/layout/widget_layout.xml"
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="horizontal"
    android:gravity="center_vertical"
    android:padding="3dp"
    android:background="@drawable/widget_capsule_bg">

    <!-- Sisi Kiri (Brand & Logo): Biru #3B82F6 Gradient -->
    <LinearLayout
        android:id="@+id/widget_brand_container"
        android:layout_width="0dp"
        android:layout_height="match_parent"
        android:layout_weight="1.05"
        android:orientation="horizontal"
        android:gravity="center"
        android:paddingLeft="10dp"
        android:paddingRight="10dp"
        android:paddingTop="8dp"
        android:paddingBottom="8dp"
        android:background="@drawable/widget_brand_bg">

        <ImageView
            android:id="@+id/widget_logo_icon"
            android:layout_width="24dp"
            android:layout_height="24dp"
            android:src="@drawable/icon"
            android:scaleType="fitCenter"
            android:contentDescription="MyMoney Logo" />

        <TextView
            android:id="@+id/widget_brand_title"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginLeft="6dp"
            android:text="MyMoney"
            android:textColor="#FFFFFF"
            android:textSize="12sp"
            android:textStyle="bold"
            android:singleLine="true" />
    </LinearLayout>

    <!-- Sisi Kanan (Tombol Aksi): Abu-abu gelap transparan #1E293B -->
    <LinearLayout
        android:id="@+id/widget_actions_container"
        android:layout_width="0dp"
        android:layout_height="match_parent"
        android:layout_weight="1.45"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        android:paddingLeft="4dp"
        android:paddingRight="4dp"
        android:background="@drawable/widget_actions_bg">

        <!-- Tombol (+) Pend -->
        <LinearLayout
            android:id="@+id/btn_widget_pendapatan"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:orientation="horizontal"
            android:gravity="center"
            android:paddingTop="8dp"
            android:paddingBottom="8dp"
            android:paddingLeft="4dp"
            android:paddingRight="4dp">

            <ImageView
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_widget_plus"
                android:scaleType="fitCenter" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginLeft="4dp"
                android:text="Pend"
                android:textColor="#34D399"
                android:textSize="12sp"
                android:textStyle="bold"
                android:singleLine="true" />
        </LinearLayout>

        <!-- Garis Pemisah Vertikal: Gunakan ImageView (Bukan View) agar didukung penuh RemoteViews -->
        <ImageView
            android:id="@+id/widget_divider"
            android:layout_width="1dp"
            android:layout_height="20dp"
            android:layout_gravity="center_vertical"
            android:background="#334155" />

        <!-- Tombol (-) Peng -->
        <LinearLayout
            android:id="@+id/btn_widget_pengeluaran"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:orientation="horizontal"
            android:gravity="center"
            android:paddingTop="8dp"
            android:paddingBottom="8dp"
            android:paddingLeft="4dp"
            android:paddingRight="4dp">

            <ImageView
                android:layout_width="16dp"
                android:layout_height="16dp"
                android:src="@drawable/ic_widget_minus"
                android:scaleType="fitCenter" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginLeft="4dp"
                android:text="Peng"
                android:textColor="#F87171"
                android:textSize="12sp"
                android:textStyle="bold"
                android:singleLine="true" />
        </LinearLayout>
    </LinearLayout>
</LinearLayout>
EOF

# Sediakan juga salinan dengan nama appwidget_provider_layout.xml untuk kompatibilitas penuh
cp "$WORKDIR/res/layout/widget_layout.xml" "$WORKDIR/res/layout/appwidget_provider_layout.xml"

# 5. Create HD App Icon PNG & Widget Icons
python3 -c "
import struct, zlib, math

def make_png(width, height, draw_func):
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        for x in range(width):
            r, g, b, a = draw_func(x, y, width, height)
            raw.extend([r, g, b, a])
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', idat) + chunk(b'IEND', b'')

def draw_icon(x, y, width, height):
    half = width / 2.0
    rad = half * 0.44
    dx = x - half
    dy = y - half
    dist = math.sqrt(dx*dx + dy*dy)
    if dist < rad:
        factor = (x + y) / (2.0 * width)
        r = int(59 + factor * 20)
        g = int(130 - factor * 20)
        b = int(246 - factor * 10)
        norm_x = (x - half) / (rad * 0.65)
        norm_y = (y - half) / (rad * 0.65)
        is_m = False
        if -0.6 <= norm_x <= 0.6 and -0.6 <= norm_y <= 0.6:
            if abs(norm_x) >= 0.42:
                is_m = True
            elif abs(norm_y - (abs(norm_x) * 1.5 - 0.4)) < 0.2 and norm_y >= -0.4:
                is_m = True
        if is_m:
            return 255, 255, 255, 255
        return r, g, b, 255
    return 9, 13, 22, 255

def draw_plus(x, y, w, h):
    cx, cy = w / 2.0, h / 2.0
    dx, dy = x - cx, y - cy
    dist = math.sqrt(dx*dx + dy*dy)
    if dist <= cx - 2:
        if (abs(dx) <= 2 and abs(dy) <= 10) or (abs(dy) <= 2 and abs(dx) <= 10):
            return 255, 255, 255, 255
        return 16, 185, 129, 255
    return 0, 0, 0, 0

def draw_minus(x, y, w, h):
    cx, cy = w / 2.0, h / 2.0
    dx, dy = x - cx, y - cy
    dist = math.sqrt(dx*dx + dy*dy)
    if dist <= cx - 2:
        if abs(dy) <= 2 and abs(dx) <= 10:
            return 255, 255, 255, 255
        return 239, 68, 68, 255
    return 0, 0, 0, 0

def draw_preview(x, y, w, h):
    mx = 8
    my = 8
    rx = 26
    if x < mx or x > w - mx or y < my or y > h - my:
        return 0, 0, 0, 0
    if x < mx + rx:
        dx = x - (mx + rx)
        if y < my + rx:
            dy = y - (my + rx)
            if dx*dx + dy*dy > rx*rx: return 0, 0, 0, 0
        elif y > h - my - rx:
            dy = y - (h - my - rx)
            if dx*dx + dy*dy > rx*rx: return 0, 0, 0, 0
    if x > w - mx - rx:
        dx = x - (w - mx - rx)
        if y < my + rx:
            dy = y - (my + rx)
            if dx*dx + dy*dy > rx*rx: return 0, 0, 0, 0
        elif y > h - my - rx:
            dy = y - (h - my - rx)
            if dx*dx + dy*dy > rx*rx: return 0, 0, 0, 0

    if x < 120:
        factor = (x - mx) / 112.0
        r = int(37 + factor * 22)
        g = int(99 + factor * 31)
        b = int(235 + factor * 11)
        cx, cy = 40, 40
        dx = x - cx
        dy = y - cy
        if dx*dx + dy*dy <= 16*16:
            if abs(dx) == 7 or (abs(dy - abs(dx)) <= 2 and dy <= 4 and dy >= -7):
                return 255, 255, 255, 255
            return 255, 255, 255, 60
        return r, g, b, 255
    elif x == 120:
        return 51, 65, 85, 255
    else:
        if x == 198 and abs(y - 40) <= 15:
            return 51, 65, 85, 255
        dx_pend = x - 150
        dy_pend = y - 40
        if dx_pend*dx_pend + dy_pend*dy_pend <= 11*11:
            if (abs(dx_pend) <= 2 and abs(dy_pend) <= 7) or (abs(dy_pend) <= 2 and abs(dx_pend) <= 7):
                return 255, 255, 255, 255
            return 16, 185, 129, 255
        dx_peng = x - 235
        dy_peng = y - 40
        if dx_peng*dx_peng + dy_peng*dy_peng <= 11*11:
            if abs(dy_peng) <= 2 and abs(dx_peng) <= 7:
                return 255, 255, 255, 255
            return 239, 68, 68, 255
        return 30, 41, 59, 255

png_plus = make_png(48, 48, draw_plus)
with open('$WORKDIR/res/drawable/ic_widget_plus.png', 'wb') as f: f.write(png_plus)

png_minus = make_png(48, 48, draw_minus)
with open('$WORKDIR/res/drawable/ic_widget_minus.png', 'wb') as f: f.write(png_minus)

png_preview = make_png(280, 80, draw_preview)
with open('$WORKDIR/res/drawable/widget_preview.png', 'wb') as f: f.write(png_preview)
"

# Copy Official High-Res Icon Assets into all Mipmap Densities and Drawable
cp -r /app/applet/public/res_icons/* "$WORKDIR/res/"
cp /app/applet/public/res_icons/mipmap-xxxhdpi/icon.png "$WORKDIR/res/drawable/icon.png"

# 6. Copy Clean HTML into assets
sed -e 's|<script type="module" src="/src/main.tsx"></script>||g' \
    -e '/id="web-apk-download-bar"/,/<\/div>/d' \
    "/app/applet/index.html" > "$WORKDIR/assets/index.html"

# 7. AppWidgetProvider Java Code: QuickRecordWidgetProvider.java
cat << 'EOF' > "$WORKDIR/src/com/tpex/mymoney/QuickRecordWidgetProvider.java"
package com.tpex.mymoney;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;

public class QuickRecordWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final int count = appWidgetIds.length;
        for (int i = 0; i < count; i++) {
            updateAppWidget(context, appWidgetManager, appWidgetIds[i]);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        int flag = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) {
            flag |= 0x04000000; // PendingIntent.FLAG_IMMUTABLE
        }

        // 1. PendingIntent untuk Brand & Logo Kiri (Buka Beranda MyMoney)
        Intent homeIntent = new Intent(context, MainActivity.class);
        homeIntent.setAction(Intent.ACTION_MAIN);
        homeIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent homePendingIntent = PendingIntent.getActivity(context, 200, homeIntent, flag);
        views.setOnClickPendingIntent(R.id.widget_brand_container, homePendingIntent);

        // 2. PendingIntent untuk Tombol (+) Pend (Buka Form Pendapatan)
        Intent incIntent = new Intent(context, MainActivity.class);
        incIntent.setAction("com.tpex.mymoney.ACTION_ADD_TX");
        incIntent.setData(Uri.parse("mymoney://addTx?action=addTx&type=pendapatan"));
        incIntent.putExtra("action", "addTx");
        incIntent.putExtra("type", "pendapatan");
        incIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent incPendingIntent = PendingIntent.getActivity(context, 201, incIntent, flag);
        views.setOnClickPendingIntent(R.id.btn_widget_pendapatan, incPendingIntent);

        // 3. PendingIntent untuk Tombol (-) Peng (Buka Form Pengeluaran)
        Intent expIntent = new Intent(context, MainActivity.class);
        expIntent.setAction("com.tpex.mymoney.ACTION_ADD_TX");
        expIntent.setData(Uri.parse("mymoney://addTx?action=addTx&type=pengeluaran"));
        expIntent.putExtra("action", "addTx");
        expIntent.putExtra("type", "pengeluaran");
        expIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent expPendingIntent = PendingIntent.getActivity(context, 202, expIntent, flag);
        views.setOnClickPendingIntent(R.id.btn_widget_pengeluaran, expPendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
EOF

# 8. MainActivity.java (Mendukung Dynamic Routing & onNewIntent, tanpa in-app shortcut bridge yang sudah dibersihkan)
cat << 'EOF' > "$WORKDIR/src/com/tpex/mymoney/MainActivity.java"
package com.tpex.mymoney;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor("#090D16"));
            window.setNavigationBarColor(Color.parseColor("#090D16"));
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);

        String defaultUA = settings.getUserAgentString();
        settings.setUserAgentString(defaultUA + " MyMoneyNativeAPK/2.7.1");

        // WebAppInterface HANYA untuk ekspor file CSV
        class WebAppInterface {
            Context mContext;
            WebAppInterface(Context c) { mContext = c; }

            @JavascriptInterface
            public void saveCsv(String csvContent, String filename) {
                saveDataToFile(csvContent, filename);
            }
        }

        WebAppInterface webAppInterface = new WebAppInterface(this);
        webView.addJavascriptInterface(webAppInterface, "Android");
        webView.addJavascriptInterface(webAppInterface, "AndroidDownloader");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                try {
                    if (url.startsWith("data:")) {
                        saveDataUrl(url, contentDisposition);
                    } else {
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                        request.setMimeType(mimeType != null ? mimeType : "text/csv");
                        String cookies = CookieManager.getInstance().getCookie(url);
                        if (cookies != null) request.addRequestHeader("cookie", cookies);
                        request.addRequestHeader("User-Agent", userAgent);
                        request.setDescription("Mengunduh laporan keuangan MyMoney...");
                        String filename = URLUtil.guessFileName(url, contentDisposition, mimeType);
                        request.setTitle(filename);
                        request.allowScanningByMediaScanner();
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                        if (dm != null) {
                            dm.enqueue(request);
                            Toast.makeText(MainActivity.this, "Mengunduh berkas: " + filename, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal mengunduh: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
            }
        }

        registerLauncherShortcuts();

        // Resolusi Routing Parameter saat aplikasi dibuka dari Homescreen Widget
        String urlToLoad = "file:///android_asset/index.html";
        Intent intent = getIntent();
        if (intent != null) {
            String routeUrl = resolveRouteFromIntent(intent);
            if (routeUrl != null) {
                urlToLoad = routeUrl;
            }
        }
        webView.loadUrl(urlToLoad);
    }

    private String resolveRouteFromIntent(Intent intent) {
        if (intent == null) return null;
        String action = intent.getStringExtra("action");
        String intentAction = intent.getAction();
        Uri data = intent.getData();

        String type = intent.getStringExtra("type");
        if (data != null && data.getQueryParameter("type") != null) {
            type = data.getQueryParameter("type");
        }
        if (type == null || (!type.equals("pendapatan") && !type.equals("pengeluaran"))) {
            type = (intentAction != null && intentAction.toLowerCase().contains("pendapatan")) ? "pendapatan" : "pengeluaran";
        }

        boolean isAddTx = "addTx".equals(action) ||
                          "com.tpex.mymoney.ACTION_ADD_TX".equals(intentAction) ||
                          (data != null && ("addTx".equals(data.getHost()) || "addTx".equals(data.getQueryParameter("action"))));

        if (isAddTx) {
            return "file:///android_asset/index.html?action=addTx&type=" + type;
        }
        return null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && webView != null) {
            String action = intent.getStringExtra("action");
            String intentAction = intent.getAction();
            Uri data = intent.getData();

            String type = intent.getStringExtra("type");
            if (data != null && data.getQueryParameter("type") != null) {
                type = data.getQueryParameter("type");
            }
            if (type == null || (!type.equals("pendapatan") && !type.equals("pengeluaran"))) {
                type = (intentAction != null && intentAction.toLowerCase().contains("pendapatan")) ? "pendapatan" : "pengeluaran";
            }

            boolean isAddTx = "addTx".equals(action) ||
                              "com.tpex.mymoney.ACTION_ADD_TX".equals(intentAction) ||
                              (data != null && ("addTx".equals(data.getHost()) || "addTx".equals(data.getQueryParameter("action"))));

            if (isAddTx) {
                final String targetType = type;
                webView.post(new Runnable() {
                    @Override
                    public void run() {
                        webView.loadUrl("javascript:if(typeof handleWidgetAction==='function'){handleWidgetAction('" + targetType + "');}else{if(typeof setTxTab==='function')setTxTab('" + targetType + "');if(typeof openTxForm==='function')openTxForm('" + targetType + "');}");
                    }
                });
            }
        }
    }

    private void registerLauncherShortcuts() {
        if (Build.VERSION.SDK_INT >= 25) {
            try {
                Object shortcutManager = getSystemService("shortcut");
                if (shortcutManager != null) {
                    Class<?> smClass = Class.forName("android.content.pm.ShortcutManager");
                    Class<?> siBuilderClass = Class.forName("android.content.pm.ShortcutInfo$Builder");
                    Class<?> iconClass = Class.forName("android.graphics.drawable.Icon");

                    // 1. Shortcut: Catat Pengeluaran
                    Object bPeng = siBuilderClass.getConstructor(Context.class, String.class).newInstance(this, "addTxPengeluaran");
                    siBuilderClass.getMethod("setShortLabel", CharSequence.class).invoke(bPeng, "- Peng");
                    siBuilderClass.getMethod("setLongLabel", CharSequence.class).invoke(bPeng, "- Catat Pengeluaran");
                    java.lang.reflect.Method createWithResource = iconClass.getMethod("createWithResource", Context.class, int.class);
                    Object iconPeng = createWithResource.invoke(null, this, R.drawable.ic_widget_minus);
                    siBuilderClass.getMethod("setIcon", iconClass).invoke(bPeng, iconPeng);

                    Intent sIntentPeng = new Intent(this, MainActivity.class);
                    sIntentPeng.setAction("com.tpex.mymoney.ACTION_ADD_TX");
                    sIntentPeng.putExtra("action", "addTx");
                    sIntentPeng.putExtra("type", "pengeluaran");
                    sIntentPeng.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    siBuilderClass.getMethod("setIntent", Intent.class).invoke(bPeng, sIntentPeng);
                    Object siPeng = siBuilderClass.getMethod("build").invoke(bPeng);

                    // 2. Shortcut: Catat Pendapatan
                    Object bPend = siBuilderClass.getConstructor(Context.class, String.class).newInstance(this, "addTxPendapatan");
                    siBuilderClass.getMethod("setShortLabel", CharSequence.class).invoke(bPend, "+ Pend");
                    siBuilderClass.getMethod("setLongLabel", CharSequence.class).invoke(bPend, "+ Catat Pendapatan");
                    Object iconPend = createWithResource.invoke(null, this, R.drawable.ic_widget_plus);
                    siBuilderClass.getMethod("setIcon", iconClass).invoke(bPend, iconPend);

                    Intent sIntentPend = new Intent(this, MainActivity.class);
                    sIntentPend.setAction("com.tpex.mymoney.ACTION_ADD_TX");
                    sIntentPend.putExtra("action", "addTx");
                    sIntentPend.putExtra("type", "pendapatan");
                    sIntentPend.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    siBuilderClass.getMethod("setIntent", Intent.class).invoke(bPend, sIntentPend);
                    Object siPend = siBuilderClass.getMethod("build").invoke(bPend);

                    java.util.List list = java.util.Arrays.asList(siPeng, siPend);
                    smClass.getMethod("setDynamicShortcuts", java.util.List.class).invoke(shortcutManager, list);
                }
            } catch (Throwable t) {
                // Ignore gracefully on older Android
            }
        }
    }

    private void saveDataUrl(String dataUrl, String contentDisposition) {
        try {
            String filename = "MyMoney_Laporan_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".csv";
            String dataPart = dataUrl;
            int commaIndex = dataUrl.indexOf(",");
            if (commaIndex != -1) {
                dataPart = dataUrl.substring(commaIndex + 1);
            }
            byte[] bytes;
            if (dataUrl.contains(";base64,")) {
                bytes = Base64.decode(dataPart, Base64.DEFAULT);
            } else {
                bytes = Uri.decode(dataPart).getBytes("UTF-8");
            }
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!downloadsDir.exists()) downloadsDir.mkdirs();
            File file = new File(downloadsDir, filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
            Toast.makeText(this, "Laporan disimpan di Download: " + filename, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyimpan file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void saveDataToFile(String content, String filename) {
        try {
            if (filename == null || filename.isEmpty()) {
                filename = "MyMoney_Laporan_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".csv";
            }
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!downloadsDir.exists()) downloadsDir.mkdirs();
            File file = new File(downloadsDir, filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(content.getBytes("UTF-8"));
            fos.flush();
            fos.close();
            Toast.makeText(this, "Laporan disimpan di Download: " + filename, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyimpan file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
EOF

echo "--- 1. Generating R.java with aapt ---"
aapt package -f -m \
    -J "$WORKDIR/src" \
    -M "$WORKDIR/AndroidManifest.xml" \
    -S "$WORKDIR/res" \
    -I "$ANDROID_JAR"

echo "--- 2. Compiling Java with javac ---"
javac -source 8 -target 8 \
    -bootclasspath "$ANDROID_JAR" \
    -cp "$ANDROID_JAR:$WORKDIR/src" \
    -d "$WORKDIR/bin/classes" \
    "$WORKDIR/src/com/tpex/mymoney/R.java" \
    "$WORKDIR/src/com/tpex/mymoney/QuickRecordWidgetProvider.java" \
    "$WORKDIR/src/com/tpex/mymoney/MainActivity.java"

echo "--- 3. Converting to classes.dex with dx ---"
"$DX" --dex --output="$WORKDIR/bin/classes.dex" "$WORKDIR/bin/classes"

echo "--- 4. Creating base APK with aapt ---"
aapt package -f \
    -M "$WORKDIR/AndroidManifest.xml" \
    -S "$WORKDIR/res" \
    -A "$WORKDIR/assets" \
    -I "$ANDROID_JAR" \
    -F "$WORKDIR/bin/unaligned.apk"

echo "--- 5. Adding classes.dex to APK ---"
cd "$WORKDIR/bin"
aapt add unaligned.apk classes.dex

echo "--- 6. Aligning APK with zipalign ---"
zipalign -v -p 4 unaligned.apk aligned.apk

echo "--- 7. Generating Keystore & Signing APK ---"
KEYSTORE="$WORKDIR/mymoney-release.keystore"
keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -alias mymoney \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass mymoney123 \
    -keypass mymoney123 \
    -dname "CN=MyMoney, OU=Finance, O=TPex, L=Jakarta, ST=DKI, C=ID"

apksigner sign \
    --ks "$KEYSTORE" \
    --ks-key-alias mymoney \
    --ks-pass pass:mymoney123 \
    --key-pass pass:mymoney123 \
    --out "/app/applet/public/MyMoney.apk" \
    aligned.apk

# Copy directly to public/downloads and dist
cp "/app/applet/public/MyMoney.apk" "/app/applet/public/downloads/MyMoney.apk"
cp "/app/applet/public/MyMoney.apk" "/app/applet/dist/MyMoney.apk"

echo "=== VERIFIKASI APK ==="
apksigner verify --verbose "/app/applet/public/MyMoney.apk"
ls -lh "/app/applet/public/MyMoney.apk"

echo "=== SUKSES! Build APK MyMoney com.tpex.mymoney berhasil selesai! ==="

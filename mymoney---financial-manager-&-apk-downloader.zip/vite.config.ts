import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

const __dirname = import.meta.dirname || path.dirname(fileURLToPath(import.meta.url));

function apkMimePlugin() {
  return {
    name: 'apk-mime-plugin',
    configureServer(server: any) {
      server.middlewares.use((req: any, res: any, next: any) => {
        if (req.url && (req.url === '/MyMoney.apk' || req.url === '/downloads/MyMoney.apk' || req.url.includes('MyMoney.apk'))) {
          const candidates = [
            path.resolve(__dirname, 'public/MyMoney.apk'),
            path.resolve(__dirname, 'public/downloads/MyMoney.apk'),
            path.resolve(__dirname, 'dist/MyMoney.apk'),
          ];
          for (const cand of candidates) {
            if (fs.existsSync(cand)) {
              const stat = fs.statSync(cand);
              res.setHeader('Content-Type', 'application/vnd.android.package-archive');
              res.setHeader('Content-Disposition', 'attachment; filename="MyMoney.apk"');
              res.setHeader('Content-Length', stat.size);
              fs.createReadStream(cand).pipe(res);
              return;
            }
          }
        }
        if (req.url && (req.url === '/manifest.json' || req.url.startsWith('/manifest.json?'))) {
          const mPath = path.resolve(__dirname, 'public/manifest.json');
          if (fs.existsSync(mPath)) {
            res.setHeader('Content-Type', 'application/manifest+json');
            fs.createReadStream(mPath).pipe(res);
            return;
          }
        }
        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      apkMimePlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg', 'pwa-192x192.png', 'pwa-512x512.png', 'shortcut-add-tx.png', 'MyMoney.apk'],
        manifest: {
          id: '/',
          name: 'MyMoney - Financial Manager',
          short_name: 'MyMoney',
          description: 'Aplikasi manajemen keuangan pribadi lengkap, offline-first & hemat baterai.',
          theme_color: '#090d16',
          background_color: '#090d16',
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
          shortcuts: [
            {
              name: '+ Catat Transaksi',
              short_name: 'Catat',
              description: 'Buka formulir untuk mencatat pengeluaran atau pendapatan baru',
              url: '/?action=addTx',
              icons: [
                {
                  src: '/shortcut-add-tx.png',
                  sizes: '192x192',
                  type: 'image/png',
                },
                {
                  src: '/pwa-192x192.png',
                  sizes: '192x192',
                  type: 'image/png',
                },
              ],
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
